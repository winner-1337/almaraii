# Al Maraii

Système de gestion et de facturation pour Al Maraii (Windows).

## Lancer / compiler

    flutter clean
    flutter pub get
    flutter run -d windows            # test
    flutter build windows --release   # version finale

Connexion initiale : `admin` / `admin` (changement du mot de passe demandé à la première connexion).

## Licence

Ce logiciel est basé sur un projet open source distribué sous licence MIT.
Le fichier `LICENSE` doit rester dans les sources, comme l'exige cette licence.
