[Setup]
AppName=Al Maraii
AppVersion=1.0.0
DefaultDirName={pf}\Al Maraii
DefaultGroupName=Al Maraii
OutputDir=Output
OutputBaseFilename=Al MaraiiSetup
Compression=lzma
SolidCompression=yes

[Files]
Source: "build\windows\x64\runner\Release\*"; DestDir: "{app}"; Flags: recursesubdirs

[Icons]
Name: "{group}\Al Maraii"; Filename: "{app}\invoiso.exe"
Name: "{commondesktop}\Al Maraii"; Filename: "{app}\invoiso.exe"
