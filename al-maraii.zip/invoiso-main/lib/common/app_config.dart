// app_config.dart  —  Al Maraii branding
class AppConfig
{
  static const kIsCloud = false;
  static const name = "Al Maraii";
  static const version = "v4.4.6";
  static const developer = "Hazem entreprises";
  static const supportEmail = "thehazem1337@gmail.com";
  // Left empty on purpose: no external links / donation pages in this build.
  static const supportForm = "";
  static const buyMeCoffee = "";
  static const website = "";
  static const license = "Propriétaire";
  static const description = "Système de gestion et de facturation pour Al Maraii.";
}
