import 'common.dart';

/// Al Maraii build: the Tunisian dinar is the only currency.
/// The symbol is "DT" (Latin letters) so it prints correctly everywhere:
/// screen, PDF invoices, receipts and thermal printers.
class SupportedCurrencies {
  static const List<CurrencyOption> all = [
    CurrencyOption(code: 'TND', symbol: 'DT', name: 'Dinar tunisien'),
  ];

  static CurrencyOption fromCode(String code) {
    return all.firstWhere(
      (c) => c.code == code,
      orElse: () => all.first,
    );
  }
}
