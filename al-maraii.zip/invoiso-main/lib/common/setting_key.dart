enum SettingKey {
  logoPosition,
  invoicePrefix,
  additionalInfo,
  thankYouNote,
  currency,
  upiId, // kept for backward-compat read only
  showUpiQr,
  upiIds, // JSON list of UpiEntry objects
  showGstFields, // whether to show GST/GSTIN fields
  fractionalQuantity, // whether to allow decimal quantities (e.g. 1.5 hrs)
  quantityLabel, // default label for the Qty column (e.g. "Words", "Hours")
  logoSize, // logo size on PDF: 'xsmall' | 'small' | 'medium' | 'large'
  businessType, // 'product' | 'service' | 'both'
  showQuantity, // whether to show quantity field (default true)
  bankAccounts, // JSON list of BankAccount objects
  showBankDetails, // whether to show bank details on PDF
  showPhone, // whether to show company phone on PDF (default true)
  showEmail, // whether to show company email on PDF (default true)
  showDiscount, // whether to show discount column on PDF (default true)
  showTypeTag, // whether to show product/service tag on invoice items (default true)
  lastUpdateCheck, // ISO timestamp of last GitHub release API call
  lastKnownLatestVersion, // latest version tag returned by last API call
  lastNotifiedVersion, // version for which the update dialog was last shown
  dateFormat, // date display pattern: 'dd/MM/yyyy' | 'MM/dd/yyyy' | 'dd MMM yyyy' | 'yyyy-MM-dd'
  showInvoiceFooterBranding, // show "Généré par Al Maraii" in invoice PDF footer
  pdfThemeColor, // custom PDF accent/theme color as #RRGGBB
  dashboardLayout, // which dashboard layout to use: 'default' | 'classic' | 'simple'
  layoutBannerDismissed, // '1' once user dismisses the new-layouts discovery banner
  themeBannerDismissed, // '1' once user dismisses the dark-mode (beta) discovery banner
  signatureImage, // base64-encoded signature image
  signaturePosition, // 'left' | 'right'
  signatureSize, // signature size on PDF: 'small' | 'medium' | 'large'
  showPreviousBalance, // whether to show calculated Previous Balance Due on PDFs
  pageSize, // 'a4' | 'a6'
  showTotalQuantity, // show total quantity row in compact template footer
  supportBannerDismissed, // milestone at which support banner was last dismissed: '10' | '50' | '100'
  invoiceStartingNumber, // starting invoice number (only editable when invoice count is zero)
  invoiceLeadingZeros, // whether generated invoice numbers are zero-padded to 8 digits (default true; locked once invoices exist)
  defaultTaxRate, // default invoice tax rate percentage (e.g. '18')
  thermalWidthMargin, // chars trimmed off the thermal printer's textbook width to avoid edge clipping on real hardware; default '1'
  thermalItemLayout, // 'table' | 'detailed' — how items print on thermal receipts; default 'table'
  invoiceTemplate, // used by cloud edition's generic setSetting/getSetting path
  companyLogo, // used by cloud edition's generic setSetting/getSetting path
  installationId, // Unique identifier for this installation. Generated on first launch and persisted locally. Used for anonymous analytics and installation tracking.
  showAliasNameInPdf, // whether to print a product's local-language alias name instead of its actual name on PDFs (default false)
  showTaxButtonInInvoicePage,
  themeMode, // app theme: 'light' | 'dark' | 'system'
  watermarkImage, // base64-encoded watermark image shown behind invoice items table
  watermarkOpacity, // watermark opacity 0.0-1.0 as string; default '0.12'
  watermarkFullPage, // 'true' to render watermark across the whole page instead of only behind the items table (default false)
  defaultInvoiceTitle, // GST document title preselected on new invoices: 'Tax Invoice' | 'Bill of Supply' | etc; null/empty = plain 'Invoice'
  allowDuplicateInvoiceItems, // whether the same product can be added twice to one invoice (default false)
  showCgstSgst, // whether to split tax into CGST/SGST (India, 50/50)
  defaultTaxMode, // 'global' | 'perItem' — default tax mode for new invoices
  showRoundOff, // whether to show round-off row + amount-in-words on PDFs (default false)
  showCompanyName, // whether to show company name on PDF (default true)
  showPan, // whether to show company PAN on PDF (default true)
  showFssai, // whether to show company FSSAI code on PDF (default true)
  showWebsite, // whether to show company website on PDF (default true)
  showAddress, // whether to show company address on PDF (default true)
  showLogo, // whether to show company logo on PDF (default true)
  productColumnsBannerDismissed, // '1' once user dismisses the product-columns discovery banner
  thermalCompanyNameSize, // 'xsmall' | 'small' | 'medium' | 'large' — company name font size on thermal receipts; default 'medium'
  lastUsedThermalPrinter, // JSON-encoded Printer of the last device successfully printed to, used to skip a full rescan on next open
  productColumnsConfig, // JSON ProductColumnsConfig — which optional product fields (and invoice extra cost) are visible/editable
  productListColumnsConfig, // JSON Map<String,bool> — which optional columns show in the product list table
  invoicePdfMetadataColumns, // JSON Map<String,bool> — which product-metadata columns print in the Grid Classic A4 invoice PDF
  shortcutsBannerDismissed, // '1' once user dismisses the keyboard-shortcuts discovery banner
  createInvoiceLayout, // which create-invoice screen layout to use: 'v1' | 'v2'
  showCustomerStatsCards, // whether the stat cards row is shown on customer management v2 (default true)
  showProductStatsCards, // whether the stat cards row is shown on product management v2 (default true)
  hideInvoiceNumberByDefault, // whether the "Hide invoice number in PDF" toggle is on by default for new invoices (default false)
  showDescriptionInPdf, // whether to print a product's description as a full-width row under each invoice item on A4 PDFs (default false)
  descriptionNewLineInPdf, // when showDescriptionInPdf is on: print the description as a full-width row below the item instead of a line under the item name (default false)
  appLocale, // app UI language code, e.g. 'en' | 'ne' | 'bo' | 'fr' | 'es' | 'hi' | 'zh'; unset/empty = follow system locale
  onboardingCompleted, // '1' once the first-login onboarding wizard has been finished or skipped
  showCustomerBusinessNameInPdf, // whether to show the customer's business name on PDFs/thermal receipts (default true; only shown when non-empty)
  showCustomerAddressInPdf, // whether to show the customer's address on PDFs (default true; only shown when non-empty)
  showCustomerPhoneInPdf, // whether to show the customer's phone on PDFs/thermal receipts (default true; only shown when non-empty)
  showCustomerEmailInPdf, // whether to show the customer's email on PDFs (default true; only shown when non-empty)
  showCustomerGstinInPdf, // whether to show the customer's GSTIN/tax id on PDFs/thermal receipts (default true; only shown when non-empty and GST fields are on)
  showTimeInPdf, // whether the invoice creation time is appended to the date on PDFs/thermal receipts (default true)
  pdfTimeFormat, // time format used when showTimeInPdf is on: '24' (HH:mm) | '12' (h:mm a); default '24'
  showSlNoInPdf, // whether to print the Sl No column in the A4/Letter invoice items table (default true)
  pdfLandscape, // whether the Grid Classic invoice PDF renders in landscape orientation (default false)
  customFieldsEnabled, // whether the user-defined Custom Fields feature is on (default false)
  customFieldDefs, // JSON list of CustomFieldDef objects
  faqCache, // cached JSON string of the last successfully fetched faq.json, used offline/on fetch failure
  lastFaqFetch, // ISO timestamp of last successful faq.json fetch
  showTaxColumn, // whether to show the per-item Tax column on A4 PDFs, for both global and per-item tax modes (default true); showCgstSgst only matters when this is on
  pdfFontSize, // 'small' | 'medium' | 'large' | 'xlarge' — text size multiplier for non-thermal invoice PDFs; default 'medium'
  pdfCompanyNameFontSize, // PdfFontSize key for the company name; empty/absent = same as pdfFontSize
  pdfDocTitleFontSize, // PdfFontSize key for the document title; empty/absent = same as pdfFontSize
  pdfTableHeaderFontSize, // PdfFontSize key for the items table header; empty/absent = same as pdfFontSize
  pdfTableItemsFontSize, // PdfFontSize key for the items table rows; empty/absent = same as pdfFontSize
  pdfTotalsFontSize, // PdfFontSize key for the totals block; empty/absent = same as pdfFontSize
}

extension SettingKeyExtension on SettingKey {
  String get key {
    switch (this) {
      case SettingKey.logoPosition:
        return 'logo_position';
      case SettingKey.invoicePrefix:
        return 'invoice_prefix';
      case SettingKey.additionalInfo:
        return 'additional_info';
      case SettingKey.thankYouNote:
        return 'thank_you_note';
      case SettingKey.currency:
        return 'currency';
      case SettingKey.upiId:
        return 'upi_id';
      case SettingKey.showUpiQr:
        return 'show_upi_qr';
      case SettingKey.upiIds:
        return 'upi_ids';
      case SettingKey.showGstFields:
        return 'show_gst_fields';
      case SettingKey.fractionalQuantity:
        return 'fractional_quantity';
      case SettingKey.quantityLabel:
        return 'quantity_label';
      case SettingKey.logoSize:
        return 'logo_size';
      case SettingKey.businessType:
        return 'business_type';
      case SettingKey.showQuantity:
        return 'show_quantity';
      case SettingKey.bankAccounts:
        return 'bank_accounts';
      case SettingKey.showBankDetails:
        return 'show_bank_details';
      case SettingKey.showPhone:
        return 'show_phone';
      case SettingKey.showEmail:
        return 'show_email';
      case SettingKey.showDiscount:
        return 'show_discount';
      case SettingKey.showTypeTag:
        return 'show_type_tag';
      case SettingKey.lastUpdateCheck:
        return 'last_update_check';
      case SettingKey.lastKnownLatestVersion:
        return 'last_known_latest_version';
      case SettingKey.lastNotifiedVersion:
        return 'last_notified_version';
      case SettingKey.dateFormat:
        return 'date_format';
      case SettingKey.showInvoiceFooterBranding:
        return 'show_invoice_footer_branding';
      case SettingKey.pdfThemeColor:
        return 'pdf_theme_color';
      case SettingKey.dashboardLayout:
        return 'dashboard_layout';
      case SettingKey.layoutBannerDismissed:
        return 'layout_banner_dismissed';
      case SettingKey.themeBannerDismissed:
        return 'theme_banner_dismissed';
      case SettingKey.signatureImage:
        return 'signature_image';
      case SettingKey.signaturePosition:
        return 'signature_position';
      case SettingKey.signatureSize:
        return 'signature_size';
      case SettingKey.showPreviousBalance:
        return 'show_previous_balance';
      case SettingKey.pageSize:
        return 'page_size';
      case SettingKey.showTotalQuantity:
        return 'show_total_quantity';
      case SettingKey.supportBannerDismissed:
        return 'support_banner_dismissed';
      case SettingKey.invoiceStartingNumber:
        return 'invoice_starting_number';
      case SettingKey.invoiceLeadingZeros:
        return 'invoice_leading_zeros';
      case SettingKey.defaultTaxRate:
        return 'default_tax_rate';
      case SettingKey.thermalWidthMargin:
        return 'thermal_width_margin';
      case SettingKey.thermalItemLayout:
        return 'thermal_item_layout';
      case SettingKey.invoiceTemplate:
        return 'invoice_template';
      case SettingKey.companyLogo:
        return 'company_logo';
      case SettingKey.installationId:
        return 'installation_id';
      case SettingKey.showAliasNameInPdf:
        return 'show_alias_name_in_pdf';
      case SettingKey.showTaxButtonInInvoicePage:
        return 'show_tax_button_in_invoice_page';
      case SettingKey.themeMode:
        return 'theme_mode';
      case SettingKey.watermarkImage:
        return 'watermark_image';
      case SettingKey.watermarkOpacity:
        return 'watermark_opacity';
      case SettingKey.watermarkFullPage:
        return 'watermark_full_page';
      case SettingKey.defaultInvoiceTitle:
        return 'default_invoice_title';
      case SettingKey.allowDuplicateInvoiceItems:
        return 'allow_duplicate_invoice_items';
      case SettingKey.showCgstSgst:
        return 'show_cgst_sgst';
      case SettingKey.defaultTaxMode:
        return 'default_tax_mode';
      case SettingKey.showRoundOff:
        return 'show_round_off';
      case SettingKey.showCompanyName:
        return 'show_company_name';
      case SettingKey.showPan:
        return 'show_pan';
      case SettingKey.showFssai:
        return 'show_fssai';
      case SettingKey.showWebsite:
        return 'show_website';
      case SettingKey.showAddress:
        return 'show_address';
      case SettingKey.showLogo:
        return 'show_logo';
      case SettingKey.productColumnsBannerDismissed:
        return 'product_columns_banner_dismissed';
      case SettingKey.thermalCompanyNameSize:
        return 'thermal_company_name_size';
      case SettingKey.lastUsedThermalPrinter:
        return 'last_used_thermal_printer';
      case SettingKey.productColumnsConfig:
        return 'product_columns_config';
      case SettingKey.productListColumnsConfig:
        return 'product_list_columns_config';
      case SettingKey.invoicePdfMetadataColumns:
        return 'invoice_pdf_metadata_columns';
      case SettingKey.shortcutsBannerDismissed:
        return 'shortcuts_banner_dismissed';
      case SettingKey.createInvoiceLayout:
        return 'create_invoice_layout';
      case SettingKey.showCustomerStatsCards:
        return 'show_customer_stats_cards';
      case SettingKey.showProductStatsCards:
        return 'show_product_stats_cards';
      case SettingKey.hideInvoiceNumberByDefault:
        return 'hide_invoice_number_by_default';
      case SettingKey.showDescriptionInPdf:
        return 'show_description_in_pdf';
      case SettingKey.descriptionNewLineInPdf:
        return 'description_new_line_in_pdf';
      case SettingKey.appLocale:
        return 'app_locale';
      case SettingKey.onboardingCompleted:
        return 'onboarding_completed';
      case SettingKey.showCustomerBusinessNameInPdf:
        return 'show_customer_business_name_in_pdf';
      case SettingKey.showCustomerAddressInPdf:
        return 'show_customer_address_in_pdf';
      case SettingKey.showCustomerPhoneInPdf:
        return 'show_customer_phone_in_pdf';
      case SettingKey.showCustomerEmailInPdf:
        return 'show_customer_email_in_pdf';
      case SettingKey.showCustomerGstinInPdf:
        return 'show_customer_gstin_in_pdf';
      case SettingKey.showTimeInPdf:
        return 'show_time_in_pdf';
      case SettingKey.pdfTimeFormat:
        return 'pdf_time_format';
      case SettingKey.showSlNoInPdf:
        return 'show_sl_no_in_pdf';
      case SettingKey.pdfLandscape:
        return 'pdf_landscape';
      case SettingKey.customFieldsEnabled:
        return 'custom_fields_enabled';
      case SettingKey.customFieldDefs:
        return 'custom_field_defs';
      case SettingKey.faqCache:
        return 'faq_cache';
      case SettingKey.lastFaqFetch:
        return 'last_faq_fetch';
      case SettingKey.showTaxColumn:
        return 'show_tax_column';
      case SettingKey.pdfFontSize:
        return 'pdf_font_size';
      case SettingKey.pdfCompanyNameFontSize:
        return 'pdf_company_name_font_size';
      case SettingKey.pdfDocTitleFontSize:
        return 'pdf_doc_title_font_size';
      case SettingKey.pdfTableHeaderFontSize:
        return 'pdf_table_header_font_size';
      case SettingKey.pdfTableItemsFontSize:
        return 'pdf_table_items_font_size';
      case SettingKey.pdfTotalsFontSize:
        return 'pdf_totals_font_size';

    }
  }
}
