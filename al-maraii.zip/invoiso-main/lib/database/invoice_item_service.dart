import 'dart:convert';

import 'package:invoiso/models/invoice_item.dart';
import 'package:invoiso/models/product.dart';
import 'package:invoiso/utils/app_logger.dart';
import 'database_helper.dart';

const _tag = 'InvoiceItemService';

class InvoiceItemService {
  static final dbHelper = DatabaseHelper();

  static Future<void> insertInvoiceItems(String invId, InvoiceItem item) async {
    final db = await dbHelper.database;
    await db.insert('invoice_items', {
      'id': item.id,
      'invoice_id': invId,
      'product_id': item.product.id,
      'product_name': item.product.name,
      'product_description': item.product.description,
      'product_price': item.product.price,
      'product_tax_rate': item.product.tax_rate,
      'product_price_includes_tax': item.product.priceIncludesTax ? 1 : 0,
      'product_hsn_code': item.product.hsncode,
      'quantity': item.quantity,
      'discount': item.discount,
      'unit_price': item.unitPrice,
      'extra_cost': item.extraCost,
      'discount_per_unit': item.discountPerUnit ? 1 : 0,
      'is_product_saved': item.isProductSaved ? 1 : 0,
      'product_type': item.product.type,
      'product_unit': item.product.unit,
      'unit': item.unit,
      'description': item.description,
      'line_metadata':
          item.metadata == null ? null : jsonEncode(item.metadata!.toMap()),
    });
  }

  static Future<List<InvoiceItem>> getInvoiceItemsByInvoiceId(String invoiceId) async {
    final db = await dbHelper.database;
    final maps = await db.query('invoice_items', where: 'invoice_id = ?', whereArgs: [invoiceId], orderBy: 'rowid ASC');
    final List<InvoiceItem> items = [];

    for (var map in maps) {
      try {
        final product = Product.fromInvoiceItemsMap(map);
        final rawUnitPrice = map['unit_price'];
        final unitPrice = rawUnitPrice == null
            ? null
            : (rawUnitPrice is int ? rawUnitPrice.toDouble() : rawUnitPrice as double);
        final rawExtraCost = map['extra_cost'];
        final extraCost = rawExtraCost == null
            ? null
            : (rawExtraCost is int ? rawExtraCost.toDouble() : rawExtraCost as double);
        items.add(
          InvoiceItem(
            id: map['id'] as String?,
            product: product,
            quantity: (map['quantity'] is int)
                ? (map['quantity'] as int).toDouble()
                : (map['quantity'] ?? 1.0) as double,
            discount: (map['discount'] is int)
                ? (map['discount'] as int).toDouble()
                : (map['discount'] ?? 0.0) as double,
            unitPrice: unitPrice,
            extraCost: extraCost,
            unit: map['unit'] as String?,
            description: map['description'] as String?,
            metadata: ProductMetadata.fromJsonString(map['line_metadata']),
            discountPerUnit: (map['discount_per_unit'] as int? ?? 0) == 1,
            isProductSaved: (map['is_product_saved'] as int? ?? 0) == 1,
          ),
        );
      } catch (e, stackTrace) {
        AppLogger.e(_tag, 'Error parsing invoice item row', e, stackTrace);
        continue;
      }
    }

    return items;
  }

  static Future<void> markProductSaved(String invoiceId, String productId) async {
    final db = await dbHelper.database;
    await db.update(
      'invoice_items',
      {'is_product_saved': 1},
      where: 'invoice_id = ? AND product_id = ?',
      whereArgs: [invoiceId, productId],
    );
  }
}
