import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:invoiso/common/constants.dart';
import 'package:invoiso/providers/repositories.dart';
import 'package:invoiso/models/user.dart';
import 'package:invoiso/utils/password_utils.dart';
import 'package:invoiso/utils/post_auth_navigation.dart';

class ChangePasswordScreen extends ConsumerStatefulWidget {
  final User user;
  final bool forced;

  const ChangePasswordScreen({
    super.key,
    required this.user,
    this.forced = false,
  });

  @override
  ConsumerState<ChangePasswordScreen> createState() => _ChangePasswordScreenState();
}

class _ChangePasswordScreenState extends ConsumerState<ChangePasswordScreen> {
  final _currentPasswordController = TextEditingController();
  final _newPasswordController = TextEditingController();
  final _confirmPasswordController = TextEditingController();
  // Explicit FocusNodes give each field a place in the focus tree and let
  // us chain them together below. Without these (and the
  // FocusTraversalGroup/textInputAction wiring further down), there's no
  // defined tab order for Flutter to follow, so pressing Tab or Enter
  // doesn't move focus between the fields.
  final _currentPasswordFocus = FocusNode();
  final _newPasswordFocus = FocusNode();
  final _confirmPasswordFocus = FocusNode();
  bool _isLoading = false;
  String? _errorMessage;
  bool _obscurePassword = true;

  @override
  void dispose() {
    _currentPasswordController.dispose();
    _newPasswordController.dispose();
    _confirmPasswordController.dispose();
    _currentPasswordFocus.dispose();
    _newPasswordFocus.dispose();
    _confirmPasswordFocus.dispose();
    super.dispose();
  }

  Future<void> _changePassword() async {
    final newPassword = _newPasswordController.text;
    final confirmPassword = _confirmPasswordController.text;

    setState(() {
      _errorMessage = null;
    });

    // Validate new password length
    if (newPassword.length < 8) {
      setState(() => _errorMessage = 'New password must be at least 8 characters.');
      return;
    }

    // Validate new password not same as username
    if (newPassword.toLowerCase() == widget.user.username.toLowerCase()) {
      setState(() => _errorMessage = 'Password cannot be the same as your username.');
      return;
    }

    // Validate confirmation matches
    if (newPassword != confirmPassword) {
      setState(() => _errorMessage = 'Passwords do not match.');
      return;
    }

    // If not forced, verify current password
    if (!widget.forced) {
      final currentPassword = _currentPasswordController.text;
      final valid = PasswordUtils.verify(
        currentPassword,
        widget.user.password,
        widget.user.salt,
      );
      if (!valid) {
        setState(() => _errorMessage = 'Current password is incorrect.');
        return;
      }
    }

    setState(() => _isLoading = true);

    try {
      if (!mounted) return;
      await ref.read(authRepositoryProvider).updatePassword(widget.user.id, newPassword);
      await ref.read(authRepositoryProvider).markPasswordChanged(widget.user.id);
      final updatedUser = await ref.read(authRepositoryProvider).getUserById(widget.user.id);
      // Get fresh user object
      if (!mounted) return;

      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(
          content: Text('Password changed successfully.'),
          backgroundColor: Colors.green,
        ),
      );

      await navigateAfterAuth(context, ref, updatedUser ?? widget.user);
    } catch (e) {
      if (!mounted) return;
      setState(() {
        _isLoading = false;
        _errorMessage = 'Failed to change password. Please try again.';
      });
    }
  }

  @override
  Widget build(BuildContext context) {
    final screenWidth = MediaQuery.sizeOf(context).width;
    // Same phone/tablet fix as login_screen.dart: fill the width (minus
    // side padding) on phones instead of the old `width * 0.3`, which
    // shrank to an unusably narrow card on tablet/phone widths.
    final isPhone = screenWidth < 600;
    final cardWidth = isPhone ? screenWidth - 48 : 460.0;
    final cardPadding = isPhone ? 20.0 : 32.0;
    return PopScope(
      canPop: !widget.forced,
      child: Scaffold(
        backgroundColor: Theme.of(context).brightness == Brightness.dark
            ? null
            : Colors.blue[50],
        body: SafeArea(
          child: Center(
            child: SingleChildScrollView(
              padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 24),
              child: Card(
            elevation: 8,
            color: Theme.of(context).colorScheme.surfaceContainer,
            child: Container(
              width: cardWidth,
              padding: EdgeInsets.all(cardPadding),
              child: FocusTraversalGroup(
                child: Column(
                  mainAxisSize: MainAxisSize.min,
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Row(
                      children: [
                        Icon(
                          Icons.lock_reset,
                          color: Theme.of(context).primaryColor,
                          size: 32,
                        ),
                        const SizedBox(width: 12),
                        Expanded(
                          child: Column(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: [
                              Text(
                                widget.forced ? 'Change Password Required' : 'Change Password',
                                style: const TextStyle(
                                  fontSize: 20,
                                  fontWeight: FontWeight.bold,
                                ),
                              ),
                              if (widget.forced)
                                Text(
                                  'You must set a new password before continuing.',
                                  style: TextStyle(
                                    fontSize: 13,
                                    color: Colors.orange[700],
                                  ),
                                ),
                            ],
                          ),
                        ),
                      ],
                    ),

                    AppSpacing.hXlarge,

                    Container(
                      padding: const EdgeInsets.all(12),
                      decoration: BoxDecoration(
                        color: Colors.amber[50],
                        border: Border.all(color: Colors.amber[300]!),
                        borderRadius: BorderRadius.circular(8),
                      ),
                      child: Row(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Icon(Icons.warning_amber_rounded, color: Colors.amber[800], size: 20),
                          const SizedBox(width: 8),
                          Expanded(
                            child: Text(
                              'Remember this password.',
                              style: TextStyle(
                                fontSize: 16,
                                fontWeight: FontWeight.bold,
                                color: Colors.amber[900],
                              ),
                            ),
                          ),
                        ],
                      ),
                    ),

                    AppSpacing.hXlarge,

                    if (!widget.forced) ...[
                      TextField(
                        controller: _currentPasswordController,
                        focusNode: _currentPasswordFocus,
                        autofocus: true,
                        obscureText: _obscurePassword,
                        textInputAction: TextInputAction.next,
                        onSubmitted: (_) => _newPasswordFocus.requestFocus(),
                        decoration: InputDecoration(
                            labelText: 'Current Password',
                            prefixIcon: Icon(Icons.lock_outline),
                            border: OutlineInputBorder(),
                            suffixIcon: IconButton(
                              icon: Icon(_obscurePassword
                                  ? Icons.visibility_outlined
                                  : Icons.visibility_off_outlined),
                              onPressed: () =>
                                  setState(() => _obscurePassword = !_obscurePassword),
                            )
                        ),
                      ),
                      AppSpacing.hMedium,
                    ],

                    TextField(
                      controller: _newPasswordController,
                      focusNode: _newPasswordFocus,
                      autofocus: widget.forced,
                      obscureText: _obscurePassword,
                      textInputAction: TextInputAction.next,
                      onSubmitted: (_) => _confirmPasswordFocus.requestFocus(),
                      decoration: InputDecoration(
                          labelText: 'New Password (min 8 characters)',
                          prefixIcon: const Icon(Icons.lock),
                          border: const OutlineInputBorder(),
                          suffixIcon: IconButton(
                            icon: Icon(_obscurePassword
                                ? Icons.visibility_outlined
                                : Icons.visibility_off_outlined),
                            onPressed: () =>
                                setState(() => _obscurePassword = !_obscurePassword),
                          )
                      ),
                    ),

                    AppSpacing.hMedium,

                    TextField(
                      controller: _confirmPasswordController,
                      focusNode: _confirmPasswordFocus,
                      obscureText: _obscurePassword,
                      textInputAction: TextInputAction.done,
                      onSubmitted: (_) => _isLoading ? null : _changePassword(),
                      decoration: InputDecoration(
                          labelText: 'Confirm New Password',
                          prefixIcon: const Icon(Icons.lock),
                          border: const OutlineInputBorder(),
                          suffixIcon: IconButton(
                            icon: Icon(_obscurePassword
                                ? Icons.visibility_outlined
                                : Icons.visibility_off_outlined),
                            onPressed: () =>
                                setState(() => _obscurePassword = !_obscurePassword),
                          )
                      ),
                    ),

                    if (_errorMessage != null) ...[
                      AppSpacing.hMedium,
                      Container(
                        padding: const EdgeInsets.all(12),
                        decoration: BoxDecoration(
                          color: Colors.red[50],
                          border: Border.all(color: Colors.red[200]!),
                          borderRadius: BorderRadius.circular(8),
                        ),
                        child: Row(
                          children: [
                            const Icon(Icons.error_outline, color: Colors.red, size: 18),
                            const SizedBox(width: 8),
                            Expanded(
                              child: Text(
                                _errorMessage!,
                                style: const TextStyle(color: Colors.red, fontSize: 13),
                              ),
                            ),
                          ],
                        ),
                      ),
                    ],

                    AppSpacing.hXlarge,

                    SizedBox(
                      width: double.infinity,
                      child: ElevatedButton(
                        onPressed: _isLoading ? null : _changePassword,
                        style: ElevatedButton.styleFrom(
                          minimumSize: const Size(double.infinity, 50),
                          backgroundColor: Theme.of(context).primaryColor,
                          foregroundColor: Colors.white,
                        ),
                        child: _isLoading
                            ? const SizedBox(
                          height: 20,
                          width: 20,
                          child: CircularProgressIndicator(
                            color: Colors.white,
                            strokeWidth: 2,
                          ),
                        )
                            : const Text('Change Password'),
                      ),
                    ),
                  ],
                ),
              ),
            ),
          ),
              ),
            ),
          ),
        ),
      );
  }
}