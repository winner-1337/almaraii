import 'dart:convert';
import 'package:invoiso/services/backend_services.dart';

import 'package:flutter/material.dart';
import 'package:intl/intl.dart';
import 'package:invoiso/common/common.dart';
import 'package:invoiso/models/invoice.dart';
import 'package:invoiso/models/invoice_payment.dart';
import 'package:invoiso/services/pdf/pdf_font_service.dart';
import 'package:invoiso/services/pdf/pdf_widgets.dart';
import 'package:pdf/pdf.dart';
import 'package:pdf/widgets.dart' as pw;
import 'package:invoiso/services/pdf/pdf_text.dart';
import 'package:printing/printing.dart';

class PaymentReceiptService {
  // ─── Public entry point ───────────────────────────────────────────────────

  /// Opens the system print/save-as-PDF dialog for the given payment receipt.
  static Future<void> printOrDownload(
    BuildContext context,
    Invoice invoice,
    InvoicePayment payment,
  ) async {
    try {
      final pdf = await _generatePDF(invoice, payment);
      await Printing.layoutPdf(
        onLayout: (_) async => pdf.save(),
        name: '${payment.receiptNumber}.pdf',
      );
    } catch (e) {
      if (context.mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(content: Text('Error generating receipt: $e')),
        );
      }
    }
  }

  // ─── PDF generation ───────────────────────────────────────────────────────

  static Future<pw.Document> _generatePDF(
    Invoice invoice,
    InvoicePayment payment,
  ) async {
    final pdfTheme = await PdfFontService.loadTheme();
    final pdf = pw.Document(theme: pdfTheme);
    final company = await BackendServices.companyInfo.getCompanyInfo();
    final base64Logo = await BackendServices.settings.getCompanyLogo();
    final logoImage =
        base64Logo != null ? pw.MemoryImage(base64Decode(base64Logo)) : null;
    final sym = invoice.currencySymbol;
    final dateFmt = (await BackendServices.settings.getDateFormat()).key;
    final leadingZerosStr =
        await BackendServices.settings.getSetting(SettingKey.invoiceLeadingZeros);
    final showLeadingZeros = leadingZerosStr != 'false';

    pdf.addPage(
      pw.Page(
        pageFormat: PdfPageFormat.a4,
        theme: pdfTheme,
        margin: const pw.EdgeInsets.all(40),
        build: (ctx) => _buildReceiptBody(
          company: company,
          invoice: invoice,
          payment: payment,
          sym: sym,
          logoImage: logoImage,
          dateFmt: dateFmt,
          showLeadingZeros: showLeadingZeros,
        ),
      ),
    );

    return pdf;
  }

  static pw.Widget _buildReceiptBody({
    required dynamic company,
    required Invoice invoice,
    required InvoicePayment payment,
    required String sym,
    required pw.MemoryImage? logoImage,
    required String dateFmt,
    required bool showLeadingZeros,
  }) {
    const accentColor = PdfColors.indigo800;
    final isPaidInFull = payment.balanceAfter <= 0;

    return pw.Column(
      crossAxisAlignment: pw.CrossAxisAlignment.start,
      children: [
        // ── Header: company info + logo ──────────────────────────────────
        pw.Row(
          mainAxisAlignment: pw.MainAxisAlignment.spaceBetween,
          crossAxisAlignment: pw.CrossAxisAlignment.start,
          children: [
            // Company details
            pw.Expanded(
              child: pw.Column(
                crossAxisAlignment: pw.CrossAxisAlignment.start,
                children: [
                  pdfText(
                    company?.name ?? '',
                    style: pw.TextStyle(
                      fontSize: 16,
                      fontWeight: pw.FontWeight.bold,
                      color: accentColor,
                    ),
                  ),
                  if ((company?.address ?? '').isNotEmpty)
                    pdfText(company!.address,
                        style: const pw.TextStyle(
                            fontSize: 9, color: PdfColors.grey700)),
                  if ((company?.phone ?? '').isNotEmpty)
                    pdfText(company!.phone,
                        style: const pw.TextStyle(
                            fontSize: 9, color: PdfColors.grey700)),
                  if ((company?.email ?? '').isNotEmpty)
                    pdfText(company!.email,
                        style: const pw.TextStyle(
                            fontSize: 9, color: PdfColors.grey700)),
                  if ((company?.gstin ?? '').isNotEmpty)
                    pdfText('${taxLabel(company?.country)}: ${company!.gstin}',
                        style: const pw.TextStyle(
                            fontSize: 9, color: PdfColors.grey700)),
                  if ((company?.panNumber ?? '').isNotEmpty)
                    pdfText('${panLabel(company?.country)}: ${company!.panNumber}',
                        style: const pw.TextStyle(
                            fontSize: 9, color: PdfColors.grey700)),
                  if ((company?.fssaiCode ?? '').isNotEmpty)
                    pdfText('FSSAI: ${company!.fssaiCode}',
                        style: const pw.TextStyle(
                            fontSize: 9, color: PdfColors.grey700)),
                ],
              ),
            ),
            // Logo
            if (logoImage != null)
              pw.Container(
                width: 70,
                height: 70,
                child: pw.Image(logoImage, fit: pw.BoxFit.contain),
              ),
          ],
        ),

        pw.SizedBox(height: 16),
        pw.Divider(color: accentColor, thickness: 1.5),
        pw.SizedBox(height: 10),

        // ── Title ────────────────────────────────────────────────────────
        pw.Center(
          child: pdfText(
            'REÇU DE PAIEMENT',
            style: pw.TextStyle(
              fontSize: 18,
              fontWeight: pw.FontWeight.bold,
              color: accentColor,
              letterSpacing: 2,
            ),
          ),
        ),

        pw.SizedBox(height: 14),

        // ── Receipt meta: number, invoice, date ───────────────────────────
        pw.Container(
          padding: const pw.EdgeInsets.all(10),
          decoration: pw.BoxDecoration(
            color: PdfColors.grey100,
            borderRadius: pw.BorderRadius.circular(4),
          ),
          child: pw.Row(
            mainAxisAlignment: pw.MainAxisAlignment.spaceBetween,
            children: [
              pw.Column(
                crossAxisAlignment: pw.CrossAxisAlignment.start,
                children: [
                  _metaRow('Reçu N°', payment.receiptNumber),
                  pw.SizedBox(height: 4),
                  _metaRow(
                      'Facture N°',
                      formatInvoiceNumberForDisplay(
                          invoice.invoiceNumber ?? invoice.id, showLeadingZeros)),
                ],
              ),
              pw.Column(
                crossAxisAlignment: pw.CrossAxisAlignment.end,
                children: [
                  _metaRow('Date', _formatDate(payment.datePaid, dateFmt)),
                  if ((payment.paymentMethod ?? '').isNotEmpty) ...[
                    pw.SizedBox(height: 4),
                    _metaRow('Mode', payment.paymentMethod!),
                  ],
                ],
              ),
            ],
          ),
        ),

        pw.SizedBox(height: 14),

        // ── Bill to ──────────────────────────────────────────────────────
        pdfText('FACTURÉ À',
            style: pw.TextStyle(
                fontSize: 9,
                fontWeight: pw.FontWeight.bold,
                color: PdfColors.grey600,
                letterSpacing: 1)),
        pw.SizedBox(height: 4),
        pdfText(invoice.customer.name,
            style: pw.TextStyle(fontSize: 11, fontWeight: pw.FontWeight.bold)),
        if (invoice.customer.businessName.isNotEmpty)
          pdfText(invoice.customer.businessName,
              style: const pw.TextStyle(fontSize: 9, color: PdfColors.grey700)),
        if (invoice.customer.address.isNotEmpty)
          pdfText(invoice.customer.address,
              style: const pw.TextStyle(fontSize: 9, color: PdfColors.grey700)),
        if (invoice.customer.phone.isNotEmpty)
          pdfText(invoice.customer.phone,
              style: const pw.TextStyle(fontSize: 9, color: PdfColors.grey700)),
        if (invoice.customer.gstin.isNotEmpty)
          pdfText('${taxLabel(company?.country)}: ${invoice.customer.gstin}',
              style: const pw.TextStyle(fontSize: 9, color: PdfColors.grey700)),

        pw.SizedBox(height: 16),
        pw.Divider(color: PdfColors.grey300),
        pw.SizedBox(height: 10),

        // ── Balance summary table ─────────────────────────────────────────
        pdfText('RÉCAPITULATIF DU SOLDE',
            style: pw.TextStyle(
                fontSize: 9,
                fontWeight: pw.FontWeight.bold,
                color: PdfColors.grey600,
                letterSpacing: 1)),
        pw.SizedBox(height: 8),

        pw.Container(
          decoration: pw.BoxDecoration(
            border: pw.Border.all(color: PdfColors.grey300),
            borderRadius: pw.BorderRadius.circular(4),
          ),
          child: pw.Column(
            children: [
              _summaryRow('Total facture', '$sym ${_fmt(invoice.total)}'),
              _summaryRow(
                  'Déjà payé', '$sym ${_fmt(payment.previouslyPaid)}'),
              _summaryRow('Ce paiement', '$sym ${_fmt(payment.amountPaid)}',
                  bold: true, highlight: PdfColors.indigo50),
              // Final row: balance due or paid in full
              pw.Container(
                padding:
                    const pw.EdgeInsets.symmetric(horizontal: 10, vertical: 8),
                decoration: pw.BoxDecoration(
                  color: isPaidInFull ? PdfColors.green700 : PdfColors.orange,
                  borderRadius: const pw.BorderRadius.vertical(
                      bottom: pw.Radius.circular(4)),
                ),
                child: pw.Row(
                  mainAxisAlignment: pw.MainAxisAlignment.spaceBetween,
                  children: [
                    pdfText(
                      isPaidInFull ? 'PAYÉ INTÉGRALEMENT' : 'Solde dû',
                      style: pw.TextStyle(
                          fontSize: 11,
                          fontWeight: pw.FontWeight.bold,
                          color: PdfColors.white),
                    ),
                    if (!isPaidInFull)
                      pdfText(
                        '$sym ${_fmt(payment.balanceAfter)}',
                        style: pw.TextStyle(
                            fontSize: 11,
                            fontWeight: pw.FontWeight.bold,
                            color: PdfColors.white),
                      ),
                  ],
                ),
              ),
            ],
          ),
        ),

        // ── Tax covered ──────────────────────────────────────────────────
        if (payment.taxAmountPaid > 0) ...[
          pw.SizedBox(height: 10),
          pdfText(
            'Tax covered by this payment: $sym ${_fmt(payment.taxAmountPaid)}',
            style: const pw.TextStyle(fontSize: 9, color: PdfColors.grey600),
          ),
        ],

        // ── Notes ────────────────────────────────────────────────────────
        if ((payment.notes ?? '').isNotEmpty) ...[
          pw.SizedBox(height: 10),
          pw.Divider(color: PdfColors.grey300),
          pw.SizedBox(height: 6),
          pdfText('Notes',
              style: pw.TextStyle(
                  fontSize: 9,
                  fontWeight: pw.FontWeight.bold,
                  color: PdfColors.grey600)),
          pw.SizedBox(height: 3),
          pdfText(payment.notes!,
              style: const pw.TextStyle(fontSize: 9, color: PdfColors.grey800)),
        ],

        pw.Spacer(),

        // ── Footer ───────────────────────────────────────────────────────
        pw.Divider(color: PdfColors.grey300),
        pw.Center(
          child: pdfText(
            'Merci pour votre paiement !',
            style: pw.TextStyle(
                fontSize: 9,
                color: accentColor,
                fontStyle: pw.FontStyle.italic),
          ),
        ),
      ],
    );
  }

  // ─── Helper widgets ───────────────────────────────────────────────────────

  static pw.Widget _metaRow(String label, String value) {
    return pw.Row(
      mainAxisSize: pw.MainAxisSize.min,
      children: [
        pdfText('$label: ',
            style: const pw.TextStyle(fontSize: 9, color: PdfColors.grey600)),
        pdfText(value,
            style: pw.TextStyle(fontSize: 9, fontWeight: pw.FontWeight.bold)),
      ],
    );
  }

  static pw.Widget _summaryRow(String label, String value,
      {bool bold = false, PdfColor? highlight}) {
    return pw.Container(
      padding: const pw.EdgeInsets.symmetric(horizontal: 10, vertical: 7),
      color: highlight,
      child: pw.Row(
        mainAxisAlignment: pw.MainAxisAlignment.spaceBetween,
        children: [
          pdfText(label,
              style: pw.TextStyle(
                  fontSize: 10,
                  fontWeight:
                      bold ? pw.FontWeight.bold : pw.FontWeight.normal)),
          pdfText(value,
              style: pw.TextStyle(
                  fontSize: 10,
                  fontWeight:
                      bold ? pw.FontWeight.bold : pw.FontWeight.normal)),
        ],
      ),
    );
  }

  static String _fmt(double v) => v.toStringAsFixed(2);

  static String _formatDate(DateTime d, String pattern) {
    return DateFormat(pattern, 'en_US').format(d);
  }
}
