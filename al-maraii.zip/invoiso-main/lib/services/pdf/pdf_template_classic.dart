import 'package:flutter/foundation.dart';
import 'package:pdf/pdf.dart';
import 'package:pdf/widgets.dart' as pw;
import 'package:invoiso/services/pdf/pdf_text.dart';
import 'package:invoiso/common/common.dart';
import 'package:invoiso/common/constants.dart';
import 'package:invoiso/models/company_info.dart';
import 'package:invoiso/models/custom_field_value.dart';
import 'package:invoiso/models/invoice.dart';
import 'pdf_widgets.dart';

pw.MultiPage buildClassicTemplate(
  Invoice invoice,
  CompanyInfo? company,
  String currencySymbol,
  String invoicePrefix, {
  String? upiId,
  bool showUpiQr = false,
  bool showGst = true,
  bool showSlNo = true,
  bool showQuantity = true,
  bool showDiscount = true,
  bool showTypeTag = true,
  bool showAliasName = false,
  bool showDescription = false,
  bool descriptionNewLine = false,
  BusinessType businessType = BusinessType.both,
  BankAccount? bankAccount,
  String datePattern = 'dd/MM/yyyy',
  LogoPosition logoPosition = LogoPosition.left,
  double logoSizePx = 90,
  Uint8List? logoBytes,
  String thankYouNote = '',
  bool showFooterBranding = true,
  PdfColor? themeColor,
  Uint8List? signatureBytes,
  String signaturePosition = 'left',
  double signatureSizePx = 50,
  double previousBalanceDue = 0.0,
  PdfPageFormat pageFormat = PdfPageFormat.a4,
  Map<String, bool> metadataColumns = const {},
  double fontSizeScale = 1.0,
  // Per-section scales; each replaces fontSizeScale for its section.
  double companyNameScale = 1.0,
  double docTitleScale = 1.0,
  double tableHeaderScale = 1.0,
  double tableItemsScale = 1.0,
  double totalsScale = 1.0,
  pw.ThemeData? pdfTheme,
  Uint8List? watermarkBytes,
  double watermarkOpacity = 0.12,
  bool watermarkFullPage = false,
  bool showCgstSgst = false,
  bool showIgst = false,
  bool showTaxColumn = true,
  bool showRoundOff = false,
  bool showLeadingZeros = true,
  bool showPhone = true,
  bool showEmail = true,
  bool showCompanyName = true,
  bool showPan = true,
  bool showFssai = true,
  bool showWebsite = true,
  bool showAddress = true,
  bool showLogo = true,
  bool showCustomerBusinessName = true,
  bool showCustomerAddress = true,
  bool showCustomerPhone = true,
  bool showCustomerEmail = true,
  bool showCustomerGstin = true,
  bool showTimeInPdf = true,
  String pdfTimeFormat = '24',
}) {
  // User's PDF text size scales every font; paddings/gaps unchanged.
  final style = classicPdfStyle.scaled(fontSizeScale);
  final accentColor = themeColor ?? PdfColors.indigo900;
  final logoImage = logoBytes != null ? pw.MemoryImage(logoBytes) : null;
  final signatureImage =
      signatureBytes != null ? pw.MemoryImage(signatureBytes) : null;
  final thankyouNote = thankYouNote;
  final title = (invoice.invoiceTitle?.trim().isNotEmpty ?? false)
      ? invoice.invoiceTitle!.toUpperCase()
      : pdfDocTypeLabel(invoice.type).toUpperCase();
  final gstin = company?.gstin ?? '';
  final gstLabel = taxLabel(company?.country);
  final panNumber = company?.panNumber ?? '';
  final fssaiCode = company?.fssaiCode ?? '';
  final companyIdParts = <String>[
    if (showGst && gstin.isNotEmpty) '$gstLabel: $gstin',
    if (showPan && panNumber.isNotEmpty) '${panLabel(company?.country)}: $panNumber',
    if (showFssai && fssaiCode.isNotEmpty && isIndiaCountry(company?.country))
      'FSSAI: $fssaiCode',
  ];
  // GSTIN + PAN + FSSAI all present → one joined line; fewer → line by line.
  final allCompanyIds = companyIdParts.length == 3;
  final companyIdLine = companyIdParts.join('   ');

  final fullPageWatermark = watermarkFullPage && watermarkBytes != null;
  return pw.MultiPage(
    pageTheme: pw.PageTheme(
      pageFormat: pageFormat,
      theme: pdfTheme,
      margin: pw.EdgeInsets.all(PdfLayout.defaultHMargin),
      buildBackground: fullPageWatermark
          ? (context) =>
              buildFullPageWatermark(watermarkBytes, watermarkOpacity)
          : null,
      buildForeground: invoice.status == 'declined'
          ? (context) => buildDeclinedStamp()
          : null,
    ),
    footer: (context) => pw.Container(
      alignment: pw.Alignment.centerRight,
      margin: const pw.EdgeInsets.only(top: 20),
      child: pdfText(
        showFooterBranding
            ? "Page ${context.pageNumber} sur ${context.pagesCount}  -  Généré par Al Maraii"
            : "Page ${context.pageNumber} sur ${context.pagesCount}",
        style: pw.TextStyle(fontSize: PdfLayout.footerBrandingFontSize * fontSizeScale, color: PdfColors.grey600),
      ),
    ),
    build: (context) => [
      pw.Row(
        mainAxisAlignment: pw.MainAxisAlignment.spaceBetween,
        crossAxisAlignment: pw.CrossAxisAlignment.start,
        children: [
          if (showLogo && logoImage != null && logoPosition == LogoPosition.left)
            buildCompanyLogo(logoImage, size: logoSizePx),
          pw.Container(
            padding:
                const pw.EdgeInsets.symmetric(horizontal: 10, vertical: 8),
            decoration: pw.BoxDecoration(
              color: PdfColors.grey100,
              borderRadius: pw.BorderRadius.circular(4),
              border: pw.Border.all(color: PdfColors.grey300, width: 0.5),
            ),
            child: pw.Column(
              crossAxisAlignment: pw.CrossAxisAlignment.start,
              children: [
                pdfText(showCompanyName ? (company?.name ?? '') : '',
                    style: pw.TextStyle(
                        fontSize: classicPdfStyle.titleFontSize * companyNameScale,
                        fontWeight: pw.FontWeight.bold,
                        color: accentColor)),
                pw.SizedBox(height: 4),
                if (showAddress)
                  pdfText(company?.address ?? '',
                      style: pw.TextStyle(fontSize: style.subtitleFontSize)),
                if (showPhone)
                  pdfText('Phone: ${company?.phone ?? ''}',
                      style: pw.TextStyle(fontSize: style.subtitleFontSize)),
                if (showEmail)
                  pdfText('Email: ${company?.email ?? ''}',
                      style: pw.TextStyle(fontSize: style.subtitleFontSize)),
                if (showWebsite && (company?.website ?? '').isNotEmpty)
                  pdfText('Web: ${company!.website}',
                      style: pw.TextStyle(fontSize: style.subtitleFontSize)),
              ],
            ),
          ),
          if (showLogo && logoImage != null && logoPosition == LogoPosition.right)
            buildCompanyLogo(logoImage, size: logoSizePx),
        ],
      ),

      pw.SizedBox(height: 6),
      if (allCompanyIds && companyIdLine.isNotEmpty)
        pw.Center(child: pdfText(companyIdLine,
            style: pw.TextStyle(
                fontStyle: pw.FontStyle.normal,
                fontSize: style.subtitleFontSize,
                color: PdfColors.grey700)),)
      else
        for (final id in companyIdParts)
          pw.Center(child: pdfText(id,
              style: pw.TextStyle(
                  fontSize: style.subtitleFontSize,
                  color: PdfColors.grey700))),
      pw.Divider(thickness: 1, color: accentColor),
      //pw.SizedBox(height: classicPdfStyle.headerGap),
      pw.Center(child: pdfText(title,
        style: pw.TextStyle(fontWeight: pw.FontWeight.bold, fontSize: classicPdfStyle.typeFont * docTitleScale),),),
      pw.Row(
        crossAxisAlignment: pw.CrossAxisAlignment.start,
        mainAxisAlignment: pw.MainAxisAlignment.spaceBetween,
        children: [
          pw.Column(
            crossAxisAlignment: pw.CrossAxisAlignment.start,
            children: [
              pw.Container(
                padding: pw.EdgeInsets.symmetric(horizontal: style.sectionPadding, vertical: style.sectionPadding),
                color: PdfColors.grey200,
                child: pdfText("FACTURÉ À",
                    style: pw.TextStyle(
                        fontWeight: pw.FontWeight.bold,
                        fontSize: style.labelFontSize,
                        color: PdfColors.grey700)),
              ),
              pw.Padding(
                padding: pw.EdgeInsets.symmetric(horizontal: style.sectionPadding, vertical: style.sectionPadding),
                child: pw.Column(
                  crossAxisAlignment: pw.CrossAxisAlignment.start,
                  children: [
                    pw.SizedBox(height: style.headerGap),
                    pdfText(invoice.customer.name,
                        style: pw.TextStyle(fontWeight: pw.FontWeight.bold, fontSize: style.bodyFontSize)),
                    if (showCustomerBusinessName && invoice.customer.businessName.isNotEmpty)
                      pdfText(invoice.customer.businessName,
                          style: pw.TextStyle(fontSize: style.bodyFontSize)),
                    if (showCustomerAddress && invoice.customer.address.isNotEmpty)
                      pdfText(invoice.customer.address,
                          style: pw.TextStyle(fontSize: style.bodyFontSize)),
                    if (showCustomerPhone && invoice.customer.phone.isNotEmpty)
                      pdfText(invoice.customer.phone,
                          style: pw.TextStyle(fontSize: style.bodyFontSize)),
                    if (showCustomerEmail && invoice.customer.email.isNotEmpty)
                      pdfText(invoice.customer.email,
                          style: pw.TextStyle(fontSize: style.bodyFontSize)),
                    if (showGst && showCustomerGstin && invoice.customer.gstin.isNotEmpty)
                      pdfText(
                          "${taxLabel(company?.country)}: ${invoice.customer.gstin}",
                          style: pw.TextStyle(
                              fontStyle: pw.FontStyle.italic,
                              fontSize: style.subtitleFontSize,
                              color: PdfColors.grey600)),
                  ],
                ),
              ),
            ],
          ),
          pw.Column(
            crossAxisAlignment: pw.CrossAxisAlignment.end,
            children: [
              if (invoice.pdfNumberText(invoicePrefix, showLeadingZeros: showLeadingZeros) != null)
                pdfText(
                    "#: ${invoice.pdfNumberText(invoicePrefix, showLeadingZeros: showLeadingZeros)}",
                    style: pw.TextStyle(fontWeight: pw.FontWeight.bold, fontSize: style.subtitleFontSize)),
              pdfText(
                  "Date: ${formatPdfDateTime(invoice.date, datePattern, showTime: showTimeInPdf, timeFormat: pdfTimeFormat)}",
                  style: pw.TextStyle(fontSize: style.bodyFontSize)),
              if (invoice.dueDate != null)
                pdfText("Due Date: ${formatPdfDate(invoice.dueDate!, datePattern)}",
                    style: pw.TextStyle(fontSize: style.bodyFontSize)),
            ],
          ),
        ],
      ),
      if (invoice.customFields.any((f) => f.value.trim().isNotEmpty)) ...[
        pw.SizedBox(height: 5),
        () {
          final filled = invoice.customFields
              .where((f) => f.value.trim().isNotEmpty)
              .toList();
          pw.Widget fieldCell(CustomFieldValue? f) => pw.Padding(
                padding: pw.EdgeInsets.symmetric(
                    horizontal: style.sectionPadding, vertical: 3),
                child: f == null
                    ? null
                    : pw.Column(
                        crossAxisAlignment: pw.CrossAxisAlignment.start,
                        children: [
                          pdfText(f.label,
                              style: pw.TextStyle(
                                  fontSize: style.subtitleFontSize,
                                  fontWeight: pw.FontWeight.bold,
                                  color: PdfColors.grey700)),
                          pdfText(f.value,
                              style: pw.TextStyle(fontSize: style.bodyFontSize)),
                        ],
                      ),
              );
          return pw.Container(
            decoration: pw.BoxDecoration(
              borderRadius: pw.BorderRadius.circular(4),
              border: pw.Border.all(color: PdfColors.grey300, width: 0.5),
            ),
            child: pw.Table(
              columnWidths: const {
                0: pw.FlexColumnWidth(1),
                1: pw.FlexColumnWidth(1),
                2: pw.FlexColumnWidth(1),
              },
              children: [
                for (var i = 0; i < filled.length; i += 3)
                  pw.TableRow(children: [
                    fieldCell(filled[i]),
                    fieldCell(i + 1 < filled.length ? filled[i + 1] : null),
                    fieldCell(i + 2 < filled.length ? filled[i + 2] : null),
                  ]),
              ],
            ),
          );
        }(),
      ],
      pw.SizedBox(height: 5),
      buildInvoiceTable(invoice,
          InvoiceTemplate.classic,
          pageFormat,
          headerColor: accentColor,
          textColor: PdfColors.white,
          showGst: showGst,
          showSlNo: showSlNo,
          showQuantity: showQuantity,
          showDiscount: showDiscount,
          showTypeTag: showTypeTag,
          showAliasName: showAliasName,
          showDescription: showDescription,
          descriptionNewLine: descriptionNewLine,
          businessType: businessType,
          watermarkBytes: fullPageWatermark ? null : watermarkBytes,
          watermarkOpacity: watermarkOpacity,
          showCgstSgst: showCgstSgst, showIgst: showIgst,
          showTaxColumn: showTaxColumn,
          tableFontSize: classicPdfStyle.tableFontSize * tableItemsScale,
          tableHeaderFontSize: classicPdfStyle.tableFontSize * tableHeaderScale,
          columnScale: tableItemsScale > tableHeaderScale ? tableItemsScale : tableHeaderScale,
          cellPaddingH: style.cellPaddingH,
          cellPaddingV: style.cellPaddingV,
          metadataColumns: metadataColumns,
          metadataDatePattern: datePattern),

      pw.SizedBox(height: 5),

      pw.Row(
        crossAxisAlignment: pw.CrossAxisAlignment.start,
        mainAxisAlignment: pw.MainAxisAlignment.spaceBetween,
        children: [
          pw.Expanded(child: buildAdditionalNotes(invoice, fontSize: 10 * fontSizeScale, accentColor: accentColor)),
          pw.SizedBox(width: 20),
          buildEnhancedTotals(
            invoice,
            PdfColors.grey200,
            PdfColors.black,
            accentColor,
            currencySymbol,
            previousBalanceDue: previousBalanceDue,
            showCgstSgst: showCgstSgst, showIgst: showIgst,
            showRoundOff: showRoundOff,
            fontSize: classicPdfStyle.totalsFontSize * totalsScale,
          ),
        ],
      ),

      if (signatureImage != null || (showUpiQr && upiId != null) || bankAccount != null) ...[
        pw.SizedBox(height: 5),
        pw.Row(
          crossAxisAlignment: pw.CrossAxisAlignment.start,
          mainAxisAlignment: pw.MainAxisAlignment.spaceBetween,
          children: signaturePosition == 'right'
              ? [
                  buildBankUpiRow(
                    bankAccount: bankAccount,
                    showUpiQr: showUpiQr,
                    upiId: upiId,
                    companyName: company?.name ?? '',
                    amount: invoice.outstandingBalance,
                    currencyCode: invoice.currencyCode,
                    invoiceId: invoice.id,
                    accentColor: accentColor,
                    bankFontSize: 7.5 * fontSizeScale,
                    sectionTitleFontSize: 8 * fontSizeScale,
                    upiIdFontSize: 7 * fontSizeScale,
                    upiAmountFontSize: 7 * fontSizeScale,
                  ),
                  signatureImage != null
                      ? buildSignatureWidget(signatureImage, signaturePosition,
                          imageHeight: signatureSizePx,
                          labelFontSize: 9 * fontSizeScale)
                      : pw.SizedBox(),
                ]
              : [
                  signatureImage != null
                      ? buildSignatureWidget(signatureImage, signaturePosition,
                          imageHeight: signatureSizePx,
                          labelFontSize: 9 * fontSizeScale)
                      : pw.SizedBox(),
                  buildBankUpiRow(
                    bankAccount: bankAccount,
                    showUpiQr: showUpiQr,
                    upiId: upiId,
                    companyName: company?.name ?? '',
                    amount: invoice.outstandingBalance,
                    currencyCode: invoice.currencyCode,
                    invoiceId: invoice.id,
                    accentColor: accentColor,
                    bankFontSize: 7.5 * fontSizeScale,
                    sectionTitleFontSize: 8 * fontSizeScale,
                    upiIdFontSize: 7 * fontSizeScale,
                    upiAmountFontSize: 7 * fontSizeScale,
                  ),
                ],
        ),
      ],

      pw.SizedBox(height: 5),
      pw.Center(
        child: pdfText(thankyouNote,
            style: pw.TextStyle(
                fontSize: PdfLayout.thankYouNoteFontSize * fontSizeScale,
                color: accentColor,
                fontStyle: pw.FontStyle.italic,
                fontWeight: pw.FontWeight.bold)),
      ),
    ],
  );
}
