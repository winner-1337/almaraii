import 'package:intl/intl.dart';
import 'package:pdf/pdf.dart';
import 'package:pdf/widgets.dart' as pw;
import 'package:invoiso/services/pdf/pdf_text.dart';
import 'package:invoiso/common/common.dart';
import 'package:invoiso/models/company_info.dart';
import 'package:invoiso/models/invoice.dart';
import 'package:invoiso/utils/amount_in_words.dart';
import 'pdf_widgets.dart';

const double _thermalMargin = 4 * PdfPageFormat.mm;

pw.Page buildThermalTemplate(
  Invoice invoice,
  CompanyInfo? company,
  String currencySymbol,
  String invoicePrefix, {
  bool showGst = true,
  bool showQuantity = true,
  bool showDiscount = true,
  bool showAliasName = false,
  bool showDescription = false,
  String datePattern = 'dd/MM/yyyy',
  String thankYouNote = '',
  bool showFooterBranding = false,
  PdfColor? themeColor,
  double previousBalanceDue = 0.0,
  PdfPageFormat pageFormat = PdfPageFormat.roll80,
  PageSize pageSize = PageSize.a4,
  pw.ThemeData? pdfTheme,
  String itemLayout = 'table',
  bool showRoundOff = false,
  bool showLeadingZeros = true,
  bool showPhone = true,
  bool showCompanyName = true,
  bool showAddress = true,
  bool showCustomerBusinessName = true,
  bool showCustomerPhone = true,
  bool showCustomerGstin = true,
  bool showTimeInPdf = true,
  String pdfTimeFormat = '24',
}) {
  const double bodyFs = 6;
  const double smallFs = 5.5;
  const double boldFs = 6;
  const double titleFs = 8.5;

  final is58 = pageSize == PageSize.thermal58;
  final useDetailedLayout = itemLayout == 'detailed';
  final totalColumnWidth = is58 ? 28.0 : 40.0;

  var totalQuantity = 0.0;

  pw.Widget sp() =>
      pw.Divider(thickness: 0.5, color: PdfColors.grey600, height: 3);

  pw.Widget dashedSep() => pw.Divider(
        thickness: 0.5,
        color: PdfColors.grey600,
        height: 3,
        borderStyle: pw.BorderStyle.dashed,
      );

  pw.Widget centerText(String text,
      {double fontSize = bodyFs,
      bool bold = false,
      PdfColor color = PdfColors.black}) {
    return pw.Center(
      child: pdfText(
        text,
        style: pw.TextStyle(
          fontSize: fontSize,
          fontWeight: bold ? pw.FontWeight.bold : pw.FontWeight.normal,
          color: color,
        ),
        textAlign: pw.TextAlign.center,
      ),
    );
  }

  pw.Widget labelValue(String label, String value, {double fontSize = bodyFs,bool valueIsBold = false}) {
    return pw.Row(
      mainAxisAlignment: pw.MainAxisAlignment.spaceBetween,
      children: [
        pdfText(label,
            style: pw.TextStyle(fontSize: fontSize, color: PdfColors.grey800)),
        pdfText(value,
            style: pw.TextStyle(
                fontSize: fontSize, fontWeight: valueIsBold ? pw.FontWeight.bold : pw.FontWeight.normal)),
      ],
    );
  }

  final showItemTax = invoice.taxMode == TaxMode.perItem;

  List<pw.Widget> buildItemRows() {
    final rows = <pw.Widget>[];
    for (var i = 0; i < invoice.items.length; i++) {
      final item = invoice.items[i];
      final qty = '${item.quantity == item.quantity.roundToDouble() ? item.quantity.toInt().toString() : item.quantity.toStringAsFixed(2)}'
          '${item.effectiveUnit.trim().isEmpty ? '' : ' ${item.effectiveUnit}'}';
      totalQuantity += item.quantity;
      final rate = item.effectivePrice.toStringAsFixed(2);
      final total = item.total.toStringAsFixed(2);

      if (useDetailedLayout) {
        // Detailed: line1 = sl+name, line2 = qty/rate/gst%/total
        rows.add(pw.Padding(
          padding: const pw.EdgeInsets.symmetric(vertical: 1.5),
          child: pw.Column(
            crossAxisAlignment: pw.CrossAxisAlignment.start,
            children: [
              pw.Row(
                crossAxisAlignment: pw.CrossAxisAlignment.start,
                children: [
                  pw.SizedBox(
                    width: 12,
                    child: pdfText('${i + 1}',
                        style: const pw.TextStyle(fontSize: smallFs)),
                  ),
                  pw.Expanded(
                    child: pdfText(item.product.displayName(showAliasName),
                        style: pw.TextStyle(
                            fontSize: smallFs,
                            fontWeight: pw.FontWeight.bold)),
                  ),
                ],
              ),
              pw.Padding(
                padding: const pw.EdgeInsets.only(left: 12),
                child: pw.Row(
                  children: [
                    pdfText('Qty:$qty',
                        style: const pw.TextStyle(fontSize: smallFs)),
                    pw.SizedBox(width: 4),
                    pw.Expanded(
                      child: pdfText('Rate:$rate',
                          style: const pw.TextStyle(fontSize: smallFs)),
                    ),
                    if (showItemTax) ...[
                      pdfText('${item.product.tax_rate}%',
                          style: const pw.TextStyle(fontSize: smallFs)),
                      pw.SizedBox(width: 4),
                    ],
                    pdfText(total,
                        style: pw.TextStyle(
                            fontSize: smallFs,
                            fontWeight: pw.FontWeight.bold)),
                  ],
                ),
              ),
              if (showDescription && item.printedDescription.isNotEmpty)
                pw.Padding(
                  padding: const pw.EdgeInsets.only(left: 12),
                  child: pdfText(
                    item.printedDescription,
                    style: const pw.TextStyle(
                        fontSize: smallFs, color: PdfColors.grey700),
                  ),
                ),
              if (showDiscount && item.totalDiscount > 0)
                pw.Padding(
                  padding: const pw.EdgeInsets.only(left: 12),
                  child: pdfText(
                    'Disc: -${item.totalDiscount.toStringAsFixed(2)}',
                    style: const pw.TextStyle(
                        fontSize: smallFs, color: PdfColors.orange800),
                  ),
                ),
            ],
          ),
        ));
      } else {
        // Table: single-line row
        rows.add(pw.Padding(
          padding: const pw.EdgeInsets.symmetric(vertical: 1.5),
          child: pw.Column(
            crossAxisAlignment: pw.CrossAxisAlignment.start,
            children: [
              pw.Row(
                crossAxisAlignment: pw.CrossAxisAlignment.start,
                children: [
                  pw.SizedBox(
                    width: 14,
                    child: pdfText('${i + 1}',
                        style: const pw.TextStyle(fontSize: smallFs)),
                  ),
                  pw.Expanded(
                    child: pdfText(item.product.displayName(showAliasName),
                        style: pw.TextStyle(fontSize: smallFs)),
                  ),
                  pw.SizedBox(
                    width: 36,
                    child: pdfText(qty,
                        textAlign: pw.TextAlign.center,
                        style: const pw.TextStyle(fontSize: smallFs)),
                  ),
                  pw.SizedBox(
                    width: 30,
                    child: pdfText(rate,
                        style: pw.TextStyle(fontSize: smallFs)),
                  ),
                  if (showItemTax)
                    pw.SizedBox(
                      width: 18,
                      child: pdfText('${item.product.tax_rate}%',
                          style: const pw.TextStyle(fontSize: smallFs)),
                    ),
                  pw.SizedBox(
                    width: totalColumnWidth,
                    child: pdfText(total,
                        textAlign: pw.TextAlign.right,
                        style: pw.TextStyle(fontSize: smallFs)),
                  ),
                ],
              ),
              if (showDescription && item.printedDescription.isNotEmpty)
                pw.Padding(
                  padding: const pw.EdgeInsets.only(left: 14),
                  child: pdfText(
                    item.printedDescription,
                    style: const pw.TextStyle(
                        fontSize: smallFs, color: PdfColors.grey700),
                  ),
                ),
              if (showDiscount && item.totalDiscount > 0)
                pw.Padding(
                  padding: const pw.EdgeInsets.only(left: 14),
                  child: pdfText(
                    'Discount: -${item.totalDiscount.toStringAsFixed(2)}',
                    style: const pw.TextStyle(
                        fontSize: smallFs, color: PdfColors.orange800),
                  ),
                ),
            ],
          ),
        ));
      }
    }
    return rows;
  }

  List<pw.Widget> buildTaxSummary() {
    if (invoice.taxMode == TaxMode.none || invoice.tax <= 0) return [];
    final totalTaxable = invoice.subtotal;
    final totalTax = invoice.tax;
    final isIndia = (company?.country ?? '').isEmpty ||
        company!.country.toLowerCase() == 'india';

    return [
      pw.SizedBox(height: 4),
      centerText('=== RÉCAP. TAXES ===', fontSize: smallFs, bold: true),
      pw.SizedBox(height: 2),
      labelValue('Base imposable :',
          '$currencySymbol ${totalTaxable.toStringAsFixed(2)}',
          fontSize: smallFs),
      if (isIndia && invoice.isInterState)
        labelValue('IGST:', '$currencySymbol ${totalTax.toStringAsFixed(2)}',
            fontSize: smallFs)
      else if (isIndia) ...[
        labelValue('SGST:', '$currencySymbol ${(totalTax / 2).toStringAsFixed(2)}',
            fontSize: smallFs),
        labelValue('CGST:', '$currencySymbol ${(totalTax / 2).toStringAsFixed(2)}',
            fontSize: smallFs),
      ],
      labelValue('Total taxes :', '$currencySymbol ${totalTax.toStringAsFixed(2)}',
          fontSize: smallFs),
    ];
  }

  List<pw.Widget> buildPdfBody() {
    final dateStr = formatPdfDateTime(invoice.date, datePattern,
        showTime: showTimeInPdf, timeFormat: pdfTimeFormat);
    final netTotal = roundNetTotal(invoice.total + previousBalanceDue);
    return [
      if (invoice.status == 'declined')
        centerText('*** REFUSÉ ***', fontSize: titleFs, bold: true),
      // ── Business Header ──
      centerText(showCompanyName ? (company?.name ?? '') : '', fontSize: titleFs, bold: true),
      pw.SizedBox(height: 2),
      if (showAddress && (company?.address ?? '').isNotEmpty)
        centerText(company!.address, fontSize: smallFs),
      if (showPhone && (company?.phone ?? '').isNotEmpty)
        centerText('Tél : ${company!.phone}', fontSize: smallFs),
      if (showGst && (company?.gstin ?? '').isNotEmpty)
        centerText('${taxLabel(company?.country)}: ${company!.gstin}',
            fontSize: smallFs),
      pw.SizedBox(height: 3),
      sp(),
      centerText(pdfDocTypeLabel(invoice.invoiceTitle ?? invoice.type).toUpperCase(), fontSize: boldFs, bold: true),
      sp(),
      pw.SizedBox(height: 3),
      // ── Invoice meta ──
      pw.Row(
        mainAxisAlignment: pw.MainAxisAlignment.spaceBetween,
        children: [
          if (invoice.pdfNumberText(invoicePrefix, showLeadingZeros: showLeadingZeros) != null)
            pdfText(
                'Inv No: ${invoice.pdfNumberText(invoicePrefix, showLeadingZeros: showLeadingZeros)}',
                style: const pw.TextStyle(fontSize: bodyFs)),
          pdfText('Date: $dateStr',
              style: const pw.TextStyle(fontSize: bodyFs)),
        ],
      ),
      if (invoice.dueDate != null)
        pw.Row(
          mainAxisAlignment: pw.MainAxisAlignment.spaceBetween,
          children: [
            pdfText('Échéance :', style: const pw.TextStyle(fontSize: bodyFs)),
            pdfText(DateFormat(datePattern, 'en_US').format(invoice.dueDate!),
                style: const pw.TextStyle(fontSize: bodyFs)),
          ],
        ),
      sp(),
      pw.SizedBox(height: 2),

      // ── Customer ──
      pdfText('Name: ${invoice.customer.name}',
          style: pw.TextStyle(
              fontSize: bodyFs, fontWeight: pw.FontWeight.bold)),
      if (showCustomerBusinessName && invoice.customer.businessName.isNotEmpty)
        pdfText(invoice.customer.businessName,
            style: const pw.TextStyle(fontSize: smallFs)),
      if (showCustomerPhone && invoice.customer.phone.isNotEmpty)
        pdfText('Tél : ${invoice.customer.phone}',
            style: const pw.TextStyle(fontSize: smallFs)),
      if (showGst && showCustomerGstin && invoice.customer.gstin.isNotEmpty)
        pdfText('${taxLabel(company?.country)}: ${invoice.customer.gstin}',
            style: const pw.TextStyle(fontSize: smallFs)),
      pw.SizedBox(height: 3),

      // ── Items header ──
      sp(),
      if (useDetailedLayout)
        pw.Row(
          children: [
            pw.SizedBox(
                width: 12,
                child: pdfText('#',
                    style: pw.TextStyle(
                        fontSize: smallFs, fontWeight: pw.FontWeight.bold))),
            pw.Expanded(
                child: pdfText('Article',
                    style: pw.TextStyle(
                        fontSize: smallFs, fontWeight: pw.FontWeight.bold))),
            pdfText('Total',
                style: pw.TextStyle(
                    fontSize: smallFs, fontWeight: pw.FontWeight.bold)),
          ],
        )
      else
        pw.Row(
          children: [
            pw.SizedBox(
                width: 14,
                child: pdfText('N°',
                    style: pw.TextStyle(
                        fontSize: smallFs, fontWeight: pw.FontWeight.bold))),
            pw.Expanded(
                child: pdfText('Désignation',
                    style: pw.TextStyle(
                        fontSize: smallFs, fontWeight: pw.FontWeight.bold))),
            pw.SizedBox(
                width: 36,
                child: pdfText('Qté',
                    textAlign: pw.TextAlign.center,
                    style: pw.TextStyle(
                        fontSize: smallFs, fontWeight: pw.FontWeight.bold))),
            pw.SizedBox(
                width: 30,
                child: pdfText('Tarif',
                    style: pw.TextStyle(
                        fontSize: smallFs, fontWeight: pw.FontWeight.bold))),
            if (showItemTax)
              pw.SizedBox(
                  width: 18,
                  child: pdfText('TVA%',
                      style: pw.TextStyle(
                          fontSize: smallFs, fontWeight: pw.FontWeight.bold))),
            pw.SizedBox(
                width: totalColumnWidth,
                child: pdfText('Total',
                    textAlign: pw.TextAlign.right,
                    style: pw.TextStyle(
                        fontSize: smallFs, fontWeight: pw.FontWeight.bold))),
          ],
        ),
      sp(),

      // ── Item rows ──
      ...buildItemRows(),
      dashedSep(),

      // ── Totals ──
      pw.SizedBox(height: 2),
      if (invoice.totalDiscount > 0)
        labelValue('Sous-total :',
            '$currencySymbol ${invoice.grossSubtotal.toStringAsFixed(2)}'),
      if (invoice.totalDiscount > 0)
        labelValue('Remise :',
            '-$currencySymbol ${invoice.totalDiscount.toStringAsFixed(2)}'),
      if (invoice.taxMode != TaxMode.none)
        labelValue(invoiceTaxLabel(invoice),
            '$currencySymbol ${invoice.tax.toStringAsFixed(2)}'),
      for (final c in invoice.additionalCosts)
        labelValue(c.label.isEmpty ? 'Frais supplémentaires' : c.label,
            '$currencySymbol ${c.amount.toStringAsFixed(2)}'),
      if (invoice.invoiceDiscountAmount > 0)
        labelValue(invoice.invoiceDiscountType == InvoiceDiscountType.percent
            ? "Extra Discount (${invoice.invoiceDiscountValue.toStringAsFixed(1)}%)"
            : "Remise supplémentaire ",
          "-$currencySymbol ${invoice.invoiceDiscountAmount.toStringAsFixed(2)}",),
      if (previousBalanceDue > 0)
        labelValue('Solde préc. :',
            '$currencySymbol ${previousBalanceDue.toStringAsFixed(2)}'),

      pw.SizedBox(height: 2),
      pw.Row(
        mainAxisAlignment: pw.MainAxisAlignment.spaceBetween,
        children: [
          pdfText('TOTAL',
              style: pw.TextStyle(
                  fontSize: boldFs, fontWeight: pw.FontWeight.bold)),
          pw.SizedBox(
              width: 30,
              child: pdfText(
                  totalQuantity == totalQuantity.roundToDouble()
                      ? totalQuantity.toInt().toString()
                      : totalQuantity.toStringAsFixed(2),
                  textAlign: pw.TextAlign.end,
                  style: pw.TextStyle(
                      fontSize: boldFs, fontWeight: pw.FontWeight.bold))),
          pdfText(
              '$currencySymbol ${(invoice.total + previousBalanceDue).toStringAsFixed(2)}',
              style: pw.TextStyle(
                  fontSize: boldFs, fontWeight: pw.FontWeight.bold)),
        ],
      ),
      if (showRoundOff) ...[
        pw.SizedBox(height: 2),
        labelValue('Arrondi :',
            '$currencySymbol ${netTotal.roundOff.toStringAsFixed(2)}'),
        pw.Row(
          mainAxisAlignment: pw.MainAxisAlignment.spaceBetween,
          children: [
            pdfText('MONTANT NET',
                style: pw.TextStyle(
                    fontSize: boldFs, fontWeight: pw.FontWeight.bold)),
            pdfText('$currencySymbol ${netTotal.rounded.toStringAsFixed(2)}',
                style: pw.TextStyle(
                    fontSize: boldFs, fontWeight: pw.FontWeight.bold)),
          ],
        ),
        pw.SizedBox(height: 2),
        pdfText(AmountInWords.amount(netTotal.rounded,
                indian: false),
            style: pw.TextStyle(
                fontSize: bodyFs - 1, fontStyle: pw.FontStyle.italic)),
      ],

      if (invoice.amountPaid > 0) ...[
        pw.SizedBox(height: 2),
        labelValue('Payé :',
            '$currencySymbol ${invoice.amountPaid.toStringAsFixed(2)}'),
        pw.Row(
          mainAxisAlignment: pw.MainAxisAlignment.spaceBetween,
          children: [
            pdfText(
                invoice.outstandingBalance <= 0 ? 'PAYÉ INTÉGRALEMENT' : 'Solde dû',
                style: pw.TextStyle(
                    fontSize: bodyFs, fontWeight: pw.FontWeight.bold)),
            if (invoice.outstandingBalance > 0)
              pdfText(
                  '$currencySymbol ${invoice.outstandingBalance.toStringAsFixed(2)}',
                  style: pw.TextStyle(
                      fontSize: bodyFs, fontWeight: pw.FontWeight.bold)),
          ],
        ),
      ],

      // ── Tax summary ──
      ...buildTaxSummary(),

      // ── Notes ──
      if ((invoice.notes ?? '').isNotEmpty) ...[
        pw.SizedBox(height: 4),
        dashedSep(),
        pdfText('NOTES',
            style: pw.TextStyle(
                fontSize: smallFs, fontWeight: pw.FontWeight.bold)),
        pdfText(invoice.notes!,
            style: pw.TextStyle(
                fontSize: smallFs, fontStyle: pw.FontStyle.italic)),
      ],

      // ── Thank you ──
      pw.SizedBox(height: 2),
      sp(),
      if (thankYouNote.isNotEmpty)
        centerText(thankYouNote,
            fontSize: bodyFs, bold: true, color: PdfColors.grey800),
      if (showFooterBranding) ...[
        pw.SizedBox(height: 4),
        centerText('Généré par Al Maraii', fontSize: (smallFs-1), color: PdfColors.grey500),
      ],
      pw.SizedBox(height: 4),
    ];
  }

  return pw.Page(
    pageFormat: pageFormat,
    theme: pdfTheme,
    margin: const pw.EdgeInsets.all(_thermalMargin),
    build: (context) => pw.Column(
      crossAxisAlignment: pw.CrossAxisAlignment.start,
      children: buildPdfBody(),
    ),
  );
}
