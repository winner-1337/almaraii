import 'package:flutter/foundation.dart';
import 'package:pdf/pdf.dart';
import 'package:pdf/widgets.dart' as pw;
import 'package:invoiso/services/pdf/pdf_text.dart';
import 'package:invoiso/common/common.dart';
import 'package:invoiso/common/constants.dart';
import 'package:invoiso/models/company_info.dart';
import 'package:invoiso/models/custom_field_value.dart';
import 'package:invoiso/models/invoice.dart';
import 'pdf_widgets.dart';

pw.MultiPage buildModernTemplate(
  Invoice invoice,
  CompanyInfo? company,
  String currencySymbol,
  String invoicePrefix, {
  String? upiId,
  bool showUpiQr = false,
  bool showGst = true,
  bool showSlNo = true,
  bool showQuantity = true,
  bool showDiscount = true,
  bool showTypeTag = true,
  bool showAliasName = false,
  bool showDescription = false,
  bool descriptionNewLine = false,
  BusinessType businessType = BusinessType.both,
  BankAccount? bankAccount,
  String datePattern = 'dd/MM/yyyy',
  LogoPosition logoPosition = LogoPosition.left,
  double logoSizePx = 90,
  Uint8List? logoBytes,
  String thankYouNote = '',
  bool showFooterBranding = true,
  PdfColor? themeColor,
  Uint8List? signatureBytes,
  String signaturePosition = 'left',
  double signatureSizePx = 50,
  double previousBalanceDue = 0.0,
  PdfPageFormat pageFormat = PdfPageFormat.a4,
  Map<String, bool> metadataColumns = const {},
  double fontSizeScale = 1.0,
  // Per-section scales; each replaces fontSizeScale for its section.
  double companyNameScale = 1.0,
  double docTitleScale = 1.0,
  double tableHeaderScale = 1.0,
  double tableItemsScale = 1.0,
  double totalsScale = 1.0,
  pw.ThemeData? pdfTheme,
  Uint8List? watermarkBytes,
  double watermarkOpacity = 0.12,
  bool watermarkFullPage = false,
  bool showCgstSgst = false,
  bool showIgst = false,
  bool showTaxColumn = true,
  bool showRoundOff = false,
  bool showLeadingZeros = true,
  bool showPhone = true,
  bool showEmail = true,
  bool showCompanyName = true,
  bool showPan = true,
  bool showFssai = true,
  bool showWebsite = true,
  bool showAddress = true,
  bool showLogo = true,
  bool showCustomerBusinessName = true,
  bool showCustomerAddress = true,
  bool showCustomerPhone = true,
  bool showCustomerEmail = true,
  bool showCustomerGstin = true,
  bool showTimeInPdf = true,
  String pdfTimeFormat = '24',
}) {
  // User's PDF text size scales every font; paddings/gaps unchanged.
  final style = modernPdfStyle.scaled(fontSizeScale);
  final accentColor = themeColor ?? PdfColors.blue600;
  final logoImage = logoBytes != null ? pw.MemoryImage(logoBytes) : null;
  final signatureImage =
      signatureBytes != null ? pw.MemoryImage(signatureBytes) : null;
  final thankyouNote = thankYouNote;

  final title = (invoice.invoiceTitle?.trim().isNotEmpty ?? false)
      ? invoice.invoiceTitle!.toUpperCase()
      : pdfDocTypeLabel(invoice.type).toUpperCase();

  final gstin = company?.gstin ?? '';
  final gstLabel = taxLabel(company?.country);
  final panNumber = company?.panNumber ?? '';
  final fssaiCode = company?.fssaiCode ?? '';
  final companyIdParts = <String>[
    if (showGst && gstin.isNotEmpty) '$gstLabel: $gstin',
    if (showPan && panNumber.isNotEmpty) '${panLabel(company?.country)}: $panNumber',
    if (showFssai && fssaiCode.isNotEmpty && isIndiaCountry(company?.country))
      'FSSAI: $fssaiCode',
  ];
  // GSTIN + PAN + FSSAI all present → one joined line; fewer → line by line.
  final allCompanyIds = companyIdParts.length == 3;
  final companyIdLine = companyIdParts.join('   ');

  final fullPageWatermark = watermarkFullPage && watermarkBytes != null;
  return pw.MultiPage(
    pageTheme: pw.PageTheme(
      pageFormat: pageFormat,
      theme: pdfTheme,
      margin: const pw.EdgeInsets.all(0),
      buildBackground: fullPageWatermark
          ? (context) =>
              buildFullPageWatermark(watermarkBytes, watermarkOpacity)
          : null,
      buildForeground: invoice.status == 'declined'
          ? (context) => buildDeclinedStamp()
          : null,
    ),
    footer: (context) => pw.Container(
      padding: const pw.EdgeInsets.symmetric(horizontal: 30, vertical: 8),
      alignment: pw.Alignment.centerRight,
      child: pdfText(
        showFooterBranding
            ? "Page ${context.pageNumber} sur ${context.pagesCount}  -  Généré par Al Maraii"
            : "Page ${context.pageNumber} sur ${context.pagesCount}",
        style: pw.TextStyle(fontSize: PdfLayout.footerBrandingFontSize * fontSizeScale, color: PdfColors.grey600),
      ),
    ),
    build: (context) => [
      pw.Container(
        color: accentColor,
        padding: pw.EdgeInsets.only(
            left: PdfLayout.defaultHMargin,
            right: PdfLayout.defaultHMargin,
            top: PdfLayout.defaultVMargin,
            bottom: PdfLayout.defaultVMargin-5),
        child: pw.Column(
          children: [
            pw.Row(
              crossAxisAlignment: pw.CrossAxisAlignment.start,
              mainAxisAlignment: pw.MainAxisAlignment.spaceBetween,
              children: [
                if (showLogo && logoImage != null && logoPosition == LogoPosition.left)
                  buildCompanyLogo(logoImage, size: logoSizePx),
                pw.Expanded(
                  flex: 2,
                  fit: pw.FlexFit.loose,
                  child: pw.Column(
                    crossAxisAlignment: pw.CrossAxisAlignment.start,
                    children: [
                      pdfText(showCompanyName ? (company?.name ?? '') : '',
                          style: pw.TextStyle(
                              fontSize: modernPdfStyle.titleFontSize * companyNameScale,
                              fontWeight: pw.FontWeight.bold,
                              color: PdfColors.white)),
                      pw.SizedBox(height: style.headerGap),
                      if (showAddress)
                        pdfText(company?.address ?? '',
                            style: pw.TextStyle(
                                color: PdfColors.white, fontSize: style.subtitleFontSize)),
                      if (showPhone)
                        pdfText('Phone: ${company?.phone ?? ''}',
                            style: pw.TextStyle(
                                color: PdfColors.white, fontSize: style.subtitleFontSize)),
                      if (showEmail)
                        pdfText('Email: ${company?.email ?? ''}',
                            style: pw.TextStyle(
                                color: PdfColors.white, fontSize: style.subtitleFontSize)),
                      if (showWebsite && (company?.website ?? '').isNotEmpty)
                        pdfText(company!.website,
                            style: pw.TextStyle(
                                color: PdfColors.white, fontSize: style.subtitleFontSize)),
                    ],
                  ),
                ),
                if (showLogo && logoImage != null && logoPosition == LogoPosition.right)
                  buildCompanyLogo(logoImage, size: logoSizePx),
              ],
            ),
          ]
        ),
      ),
      if (companyIdLine.isNotEmpty)
      pw.Container(
        color: accentColor,
        padding: pw.EdgeInsets.only(
            left: PdfLayout.defaultHMargin,
            right: PdfLayout.defaultHMargin,
            top: 0,
            bottom: PdfLayout.defaultVMargin-5),
        child: pw.Center(
          child: pw.Column(
            crossAxisAlignment: pw.CrossAxisAlignment.center,
            children: [
              for (final line in allCompanyIds ? [companyIdLine] : companyIdParts)
                pdfText(line,
                    style: pw.TextStyle(
                        color: PdfColors.white,
                        fontStyle: pw.FontStyle.italic,
                        fontSize: style.subtitleFontSize)),
            ],
          ),
        ),
      ),
      pw.SizedBox(height: 2),
      pw.Center(child: pdfText(title,
        style: pw.TextStyle(fontWeight: pw.FontWeight.bold, fontSize: modernPdfStyle.typeFont * docTitleScale),),),
      pw.Padding(
        padding: pw.EdgeInsets.fromLTRB(
            PdfLayout.defaultHMargin, 8, PdfLayout.defaultHMargin, 8),
        child: pw.Row(
          crossAxisAlignment: pw.CrossAxisAlignment.start,
          mainAxisAlignment: pw.MainAxisAlignment.spaceBetween,
          children: [
            pw.Container(
              decoration: pw.BoxDecoration(
                color: PdfColors.grey100,
                borderRadius: pw.BorderRadius.circular(6),
              ),
              padding: const pw.EdgeInsets.all(10),
              child: pw.Column(
                crossAxisAlignment: pw.CrossAxisAlignment.start,
                children: [
                  pdfText("FACTURÉ À",
                      style: pw.TextStyle(
                          fontSize: style.labelFontSize,
                          fontWeight: pw.FontWeight.bold,
                          color: accentColor)),
                  pw.SizedBox(height: 4),
                  pdfText(invoice.customer.name,
                      style: pw.TextStyle(
                          fontSize: style.bodyFontSize, fontWeight: pw.FontWeight.bold)),
                  if (showCustomerBusinessName && invoice.customer.businessName.isNotEmpty)
                    pdfText(invoice.customer.businessName,
                        style: pw.TextStyle(fontSize: style.bodyFontSize)),
                  if (showCustomerAddress && invoice.customer.address.isNotEmpty)
                    pdfText(invoice.customer.address,
                        style: pw.TextStyle(fontSize: style.bodyFontSize)),
                  if (showCustomerPhone && invoice.customer.phone.isNotEmpty)
                    pdfText(invoice.customer.phone,
                        style: pw.TextStyle(fontSize: style.bodyFontSize)),
                  if (showCustomerEmail && invoice.customer.email.isNotEmpty)
                    pdfText(invoice.customer.email,
                        style: pw.TextStyle(fontSize: style.bodyFontSize)),
                  if (showGst && showCustomerGstin && invoice.customer.gstin.isNotEmpty)
                    pdfText(
                        "${taxLabel(company?.country)}: ${invoice.customer.gstin}",
                        style: pw.TextStyle(
                            fontSize: style.bodyFontSize, fontStyle: pw.FontStyle.italic)),
                ],
              ),
            ),
            pw.Column(
              crossAxisAlignment: pw.CrossAxisAlignment.end,
              children: [
                if (invoice.pdfNumberText(invoicePrefix, showLeadingZeros: showLeadingZeros) != null)
                  pdfText(
                      "#: ${invoice.pdfNumberText(invoicePrefix, showLeadingZeros: showLeadingZeros)}",
                      style: pw.TextStyle(
                          fontWeight: pw.FontWeight.bold, fontSize: style.bodyFontSize)),
                pdfText(
                    "Date: ${formatPdfDateTime(invoice.date, datePattern, showTime: showTimeInPdf, timeFormat: pdfTimeFormat)}",
                    style: pw.TextStyle(fontSize: style.bodyFontSize)),
                if (invoice.dueDate != null)
                  pdfText(
                      "Due Date: ${formatPdfDate(invoice.dueDate!, datePattern)}",
                      style: pw.TextStyle(fontSize: style.bodyFontSize)),
              ],
            ),
          ],
        ),
      ),

      if (invoice.customFields.any((f) => f.value.trim().isNotEmpty))
        pw.Padding(
          padding: pw.EdgeInsets.fromLTRB(
              PdfLayout.defaultHMargin, 0, PdfLayout.defaultHMargin, 8),
          child: () {
            final filled = invoice.customFields
                .where((f) => f.value.trim().isNotEmpty)
                .toList();
            pw.Widget fieldCell(CustomFieldValue? f) => pw.Padding(
                  padding: const pw.EdgeInsets.only(top: 4),
                  child: f == null
                      ? null
                      : pw.Column(
                          crossAxisAlignment: pw.CrossAxisAlignment.start,
                          children: [
                            pdfText(f.label,
                                style: pw.TextStyle(
                                    fontSize: style.bodyFontSize - 1,
                                    fontWeight: pw.FontWeight.bold,
                                    color: accentColor)),
                            pdfText(f.value,
                                style: pw.TextStyle(fontSize: style.bodyFontSize)),
                          ],
                        ),
                );
            return pw.Container(
              decoration: pw.BoxDecoration(
                color: PdfColors.grey100,
                borderRadius: pw.BorderRadius.circular(6),
              ),
              padding: const pw.EdgeInsets.all(10),
              child: pw.Table(
                columnWidths: const {
                  0: pw.FlexColumnWidth(1),
                  1: pw.FlexColumnWidth(1),
                  2: pw.FlexColumnWidth(1),
                },
                children: [
                  for (var i = 0; i < filled.length; i += 3)
                    pw.TableRow(children: [
                      fieldCell(filled[i]),
                      fieldCell(i + 1 < filled.length ? filled[i + 1] : null),
                      fieldCell(i + 2 < filled.length ? filled[i + 2] : null),
                    ]),
                ],
              ),
            );
          }(),
        ),

      pw.SizedBox(height: 3),

      pw.Padding(
        padding: pw.EdgeInsets.symmetric(horizontal: PdfLayout.defaultHMargin),
        child: buildInvoiceTable(invoice,
            InvoiceTemplate.modern,
            pageFormat,
            headerColor: accentColor,
            textColor: PdfColors.white,
            showGst: showGst,
            showSlNo: showSlNo,
            showQuantity: showQuantity,
            showDiscount: showDiscount,
            showTypeTag: showTypeTag,
            showAliasName: showAliasName,
            showDescription: showDescription,
            descriptionNewLine: descriptionNewLine,
            businessType: businessType,
            watermarkBytes: fullPageWatermark ? null : watermarkBytes,
            watermarkOpacity: watermarkOpacity,
            tableFontSize: modernPdfStyle.tableFontSize * tableItemsScale,
            tableHeaderFontSize: modernPdfStyle.tableFontSize * tableHeaderScale,
            columnScale: tableItemsScale > tableHeaderScale ? tableItemsScale : tableHeaderScale,
            cellPaddingH: style.cellPaddingH,
            cellPaddingV: style.cellPaddingV,
            showCgstSgst: showCgstSgst, showIgst: showIgst,
            showTaxColumn: showTaxColumn,
            metadataColumns: metadataColumns,
            metadataDatePattern: datePattern,),
      ),

      pw.SizedBox(height: 5),

      pw.Padding(
        padding: pw.EdgeInsets.symmetric(horizontal: PdfLayout.defaultHMargin),
        child: pw.Row(
          crossAxisAlignment: pw.CrossAxisAlignment.start,
          mainAxisAlignment: pw.MainAxisAlignment.spaceBetween,
          children: [
            pw.Expanded(child: buildAdditionalNotes(invoice, fontSize: 10 * fontSizeScale, accentColor: accentColor)),
            pw.SizedBox(width: 20),
            buildEnhancedTotals(
              invoice,
              PdfColors.blue200,
              PdfColors.black,
              accentColor,
              currencySymbol,
              previousBalanceDue: previousBalanceDue,
              showCgstSgst: showCgstSgst, showIgst: showIgst,
              showRoundOff: showRoundOff,
              fontSize: modernPdfStyle.totalsFontSize * totalsScale
            ),
          ],
        ),
      ),

      if (signatureImage != null || (showUpiQr && upiId != null) || bankAccount != null) ...[
        pw.SizedBox(height: 16),
        pw.Padding(
          padding: pw.EdgeInsets.symmetric(horizontal: PdfLayout.defaultHMargin),
          child: pw.Row(
            crossAxisAlignment: pw.CrossAxisAlignment.start,
            mainAxisAlignment: pw.MainAxisAlignment.spaceBetween,
            children: signaturePosition == 'right'
                ? [
                    buildBankUpiRow(
                      bankAccount: bankAccount,
                      showUpiQr: showUpiQr,
                      upiId: upiId,
                      companyName: company?.name ?? '',
                      amount: invoice.outstandingBalance,
                      currencyCode: invoice.currencyCode,
                      invoiceId: invoice.id,
                      accentColor: accentColor,
                      bankFontSize: 7.5 * fontSizeScale,
                      sectionTitleFontSize: 8 * fontSizeScale,
                      upiIdFontSize: 7 * fontSizeScale,
                      upiAmountFontSize: 7 * fontSizeScale,
                    ),
                    signatureImage != null
                        ? buildSignatureWidget(signatureImage, signaturePosition,
                            imageHeight: signatureSizePx,
                            labelFontSize: 9 * fontSizeScale)
                        : pw.SizedBox(),
                  ]
                : [
                    signatureImage != null
                        ? buildSignatureWidget(signatureImage, signaturePosition,
                            imageHeight: signatureSizePx,
                            labelFontSize: 9 * fontSizeScale)
                        : pw.SizedBox(),
                    buildBankUpiRow(
                      bankAccount: bankAccount,
                      showUpiQr: showUpiQr,
                      upiId: upiId,
                      companyName: company?.name ?? '',
                      amount: invoice.outstandingBalance,
                      currencyCode: invoice.currencyCode,
                      invoiceId: invoice.id,
                      accentColor: accentColor,
                      bankFontSize: 7.5 * fontSizeScale,
                      sectionTitleFontSize: 8 * fontSizeScale,
                      upiIdFontSize: 7 * fontSizeScale,
                      upiAmountFontSize: 7 * fontSizeScale,
                    ),
                  ],
          ),
        ),
      ],

      pw.Spacer(),

      pw.Container(
        color: accentColor,
        padding: pw.EdgeInsets.all(PdfLayout.defaultHMargin - 12),
        child: pw.Center(
          child: pdfText(thankyouNote,
              style: pw.TextStyle(
                  color: PdfColors.white,
                  fontSize: PdfLayout.thankYouNoteFontSize * fontSizeScale,
                  fontWeight: pw.FontWeight.bold)),
        ),
      ),
    ],
  );
}
