// pdf_text.dart — Al Maraii
//
// Drop-in replacement for `pw.Text` used by every PDF template and receipt.
//
// WHY: the `pdf` package only joins Arabic letters into their connected forms
// and puts them in the right (right-to-left) order when the text is marked
// as RTL. Without that, Arabic prints as separated letters, backwards.
// This helper marks a text as RTL automatically when it contains Arabic
// characters, and leaves French / English / numbers exactly as before.
import 'package:pdf/widgets.dart' as pw;

final RegExp _arabicChars = RegExp(
    r'[؀-ۿݐ-ݿࢠ-ࣿﭐ-﷿ﹰ-﻿]');

/// True if [text] contains at least one Arabic-script character.
bool pdfHasArabic(String text) => _arabicChars.hasMatch(text);

pw.Text pdfText(
  String text, {
  pw.TextStyle? style,
  pw.TextAlign? textAlign,
  pw.TextDirection? textDirection,
  bool? softWrap,
  bool tightBounds = false,
  double textScaleFactor = 1.0,
  int? maxLines,
  pw.TextOverflow? overflow,
}) {
  return pw.Text(
    text,
    style: style,
    textAlign: textAlign,
    textDirection:
        textDirection ?? (pdfHasArabic(text) ? pw.TextDirection.rtl : null),
    softWrap: softWrap,
    tightBounds: tightBounds,
    textScaleFactor: textScaleFactor,
    maxLines: maxLines,
    overflow: overflow,
  );
}

/// French wording for the built-in document types (the stored value stays
/// English internally; only the printed label changes). Custom titles typed
/// by the user are printed as typed.
String pdfDocTypeLabel(String type) {
  switch (type.trim().toLowerCase()) {
    case 'invoice':
      return 'Facture';
    case 'quotation':
      return 'Devis';
    case 'receipt':
      return 'Reçu';
    default:
      return type;
  }
}
