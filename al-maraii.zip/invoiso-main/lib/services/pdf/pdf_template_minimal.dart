import 'package:flutter/foundation.dart';
import 'package:pdf/pdf.dart';
import 'package:pdf/widgets.dart' as pw;
import 'package:invoiso/services/pdf/pdf_text.dart';
import 'package:invoiso/common/common.dart';
import 'package:invoiso/common/constants.dart';
import 'package:invoiso/models/company_info.dart';
import 'package:invoiso/models/custom_field_value.dart';
import 'package:invoiso/models/invoice.dart';
import 'pdf_widgets.dart';

pw.MultiPage buildMinimalTemplate(
  Invoice invoice,
  CompanyInfo? company,
  String currencySymbol,
  String invoicePrefix, {
  String? upiId,
  bool showUpiQr = false,
  bool showGst = true,
  bool showSlNo = true,
  bool showQuantity = true,
  bool showDiscount = true,
  bool showTypeTag = true,
  bool showAliasName = false,
  bool showDescription = false,
  bool descriptionNewLine = false,
  BusinessType businessType = BusinessType.both,
  BankAccount? bankAccount,
  String datePattern = 'dd/MM/yyyy',
  LogoPosition logoPosition = LogoPosition.left,
  double logoSizePx = 90,
  Uint8List? logoBytes,
  String thankYouNote = '',
  bool showFooterBranding = true,
  PdfColor? themeColor,
  Uint8List? signatureBytes,
  String signaturePosition = 'left',
  double signatureSizePx = 50,
  double previousBalanceDue = 0.0,
  PdfPageFormat pageFormat = PdfPageFormat.a4,
  Map<String, bool> metadataColumns = const {},
  double fontSizeScale = 1.0,
  // Per-section scales; each replaces fontSizeScale for its section.
  double companyNameScale = 1.0,
  double docTitleScale = 1.0,
  double tableHeaderScale = 1.0,
  double tableItemsScale = 1.0,
  double totalsScale = 1.0,
  pw.ThemeData? pdfTheme,
  Uint8List? watermarkBytes,
  double watermarkOpacity = 0.12,
  bool watermarkFullPage = false,
  bool showCgstSgst = false,
  bool showIgst = false,
  bool showTaxColumn = true,
  bool showRoundOff = false,
  bool showLeadingZeros = true,
  bool showPhone = true,
  bool showEmail = true,
  bool showCompanyName = true,
  bool showPan = true,
  bool showFssai = true,
  bool showWebsite = true,
  bool showAddress = true,
  bool showLogo = true,
  bool showCustomerBusinessName = true,
  bool showCustomerAddress = true,
  bool showCustomerPhone = true,
  bool showCustomerEmail = true,
  bool showCustomerGstin = true,
  bool showTimeInPdf = true,
  String pdfTimeFormat = '24',
}) {
  // User's PDF text size scales every font; paddings/gaps unchanged.
  final style = minimalPdfStyle.scaled(fontSizeScale);
  final accentColor = themeColor ?? PdfColors.grey700;
  final logoImage = logoBytes != null ? pw.MemoryImage(logoBytes) : null;
  final signatureImage =
      signatureBytes != null ? pw.MemoryImage(signatureBytes) : null;
  final thankyouNote = thankYouNote;

  final title = (invoice.invoiceTitle?.trim().isNotEmpty ?? false)
      ? invoice.invoiceTitle!.toUpperCase()
      : pdfDocTypeLabel(invoice.type).toUpperCase();

  final gstin = company?.gstin ?? '';
  final gstLabel = taxLabel(company?.country);
  final panNumber = company?.panNumber ?? '';
  final fssaiCode = company?.fssaiCode ?? '';
  final companyIdParts = <String>[
    if (showGst && gstin.isNotEmpty) '$gstLabel: $gstin',
    if (showPan && panNumber.isNotEmpty) '${panLabel(company?.country)}: $panNumber',
    if (showFssai && fssaiCode.isNotEmpty && isIndiaCountry(company?.country))
      'FSSAI: $fssaiCode',
  ];
  // GSTIN + PAN + FSSAI all present → one joined line; fewer → line by line.
  final allCompanyIds = companyIdParts.length == 3;
  final companyIdLine = companyIdParts.join('   ');

  final fullPageWatermark = watermarkFullPage && watermarkBytes != null;
  return pw.MultiPage(
    pageTheme: pw.PageTheme(
      pageFormat: pageFormat,
      theme: pdfTheme,
      margin: pw.EdgeInsets.all(PdfLayout.defaultHMargin),
      buildBackground: fullPageWatermark
          ? (context) =>
              buildFullPageWatermark(watermarkBytes, watermarkOpacity)
          : null,
      buildForeground: invoice.status == 'declined'
          ? (context) => buildDeclinedStamp()
          : null,
    ),
    footer: (context) => pw.Container(
      alignment: pw.Alignment.centerRight,
      margin: const pw.EdgeInsets.only(top: 20),
      child: pdfText(
        showFooterBranding
            ? "Page ${context.pageNumber} sur ${context.pagesCount}  -  Généré par Al Maraii"
            : "Page ${context.pageNumber} sur ${context.pagesCount}",
        style: pw.TextStyle(fontSize: PdfLayout.footerBrandingFontSize * fontSizeScale, color: PdfColors.grey600),
      ),
    ),
    build: (context) => [
      if(logoImage == null || !showLogo)
        pw.Row(
          crossAxisAlignment: pw.CrossAxisAlignment.start,
          mainAxisAlignment: pw.MainAxisAlignment.spaceBetween,
          children: [
            pw.Column(
              crossAxisAlignment: pw.CrossAxisAlignment.start,
              children: [
                if (invoice.pdfNumberText(invoicePrefix, showLeadingZeros: showLeadingZeros) != null)
                  pdfText(invoice.pdfNumberText(invoicePrefix, showLeadingZeros: showLeadingZeros)!,
                      style: pw.TextStyle(fontSize: style.bodyFontSize)),
                pw.SizedBox(height: style.headerGap)
              ],
            ),
            pw.Column(
              crossAxisAlignment: pw.CrossAxisAlignment.end,
              children: [
                pdfText("DATE",
                    style: pw.TextStyle(
                        fontWeight: pw.FontWeight.bold,
                        fontSize: style.labelFontSize,
                        color: accentColor)),
                pdfText(
                    formatPdfDateTime(invoice.date, datePattern,
                        showTime: showTimeInPdf, timeFormat: pdfTimeFormat),
                    style: pw.TextStyle(fontSize: style.bodyFontSize)),
                if (invoice.dueDate != null) ...[
                  pw.SizedBox(height: style.headerGap),
                  pdfText("ÉCHÉANCE",
                      style: pw.TextStyle(
                          fontWeight: pw.FontWeight.bold,
                          fontSize: style.labelFontSize,
                          color: accentColor)),
                  pdfText(formatPdfDate(invoice.dueDate!, datePattern),
                      style: pw.TextStyle(fontSize: style.bodyFontSize)),
                ],
              ],
            ),
          ],
      ),
      if(showLogo && logoImage != null)
        pw.Row(
          crossAxisAlignment: pw.CrossAxisAlignment.start,
          mainAxisAlignment: pw.MainAxisAlignment.spaceBetween,
          children: [
            if (logoPosition == LogoPosition.left)
              buildCompanyLogo(logoImage, size: logoSizePx),
            pw.Column(
              crossAxisAlignment: pw.CrossAxisAlignment.start,
              children: [
                if (invoice.pdfNumberText(invoicePrefix, showLeadingZeros: showLeadingZeros) != null)
                  pdfText(invoice.pdfNumberText(invoicePrefix, showLeadingZeros: showLeadingZeros)!,
                      style: pw.TextStyle(fontSize: style.bodyFontSize)),
                pw.SizedBox(height: style.headerGap),
                pdfText("DATE",
                    style: pw.TextStyle(
                        fontWeight: pw.FontWeight.bold,
                        fontSize: style.labelFontSize,
                        color: accentColor)),
                pdfText(
                    formatPdfDateTime(invoice.date, datePattern,
                        showTime: showTimeInPdf, timeFormat: pdfTimeFormat),
                    style: pw.TextStyle(fontSize: style.bodyFontSize)),
                if (invoice.dueDate != null) ...[
                  pw.SizedBox(height: style.headerGap),
                  pdfText("ÉCHÉANCE",
                      style: pw.TextStyle(
                          fontWeight: pw.FontWeight.bold,
                          fontSize: style.labelFontSize,
                          color: accentColor)),
                  pdfText(formatPdfDate(invoice.dueDate!, datePattern),
                      style: pw.TextStyle(fontSize: style.bodyFontSize)),
                ],
              ],
            ),
            if (logoPosition == LogoPosition.right)
              buildCompanyLogo(logoImage, size: logoSizePx),
          ],
        ),
      pw.SizedBox(height: 5),
      pw.Row(
        mainAxisAlignment: pw.MainAxisAlignment.spaceEvenly,
          children: [
        if(showPhone && (company?.phone ?? '').isNotEmpty)
          pdfText(
            company?.phone != null && company!.phone!.isNotEmpty
                ? 'Tél : ${company.phone}'
                : '',
            style: pw.TextStyle(fontSize: style.bodyFontSize),
          ),
        if(showEmail && (company?.email ?? '').isNotEmpty)
          pdfText(company?.email ?? '',
            style: pw.TextStyle(fontSize: style.bodyFontSize)),
        if (showWebsite && (company?.website ?? '').isNotEmpty)
          pdfText(company!.website,
              style: pw.TextStyle(fontSize: style.bodyFontSize)),
      ]),
      pw.Divider(thickness: 0.5, color: PdfColors.grey400),
      pw.SizedBox(height: 2),
      pw.Center(child: pdfText(title,
          style: pw.TextStyle(
              fontWeight: pw.FontWeight.bold,
              fontSize: minimalPdfStyle.titleFontSize * docTitleScale,
              color: accentColor)),),
      pw.Row(
        crossAxisAlignment: pw.CrossAxisAlignment.start,
        mainAxisAlignment: pw.MainAxisAlignment.spaceBetween,
        children: [
          pw.Column(
            crossAxisAlignment: pw.CrossAxisAlignment.start,
            children: [
              pdfText("DE",
                  style: pw.TextStyle(
                      fontWeight: pw.FontWeight.bold,
                      fontSize: style.labelFontSize,
                      color: accentColor)),
              pw.SizedBox(height: style.headerGap),
              pdfText(showCompanyName ? (company?.name ?? '') : '',
                  style: pw.TextStyle(
                      fontWeight: pw.FontWeight.bold, fontSize: minimalPdfStyle.titleFontSize * companyNameScale)),
              if (showAddress)
                pdfText(company?.address ?? '',
                    style: pw.TextStyle(fontSize: style.bodyFontSize)),
              for (final line
                  in allCompanyIds ? [companyIdLine] : companyIdParts)
                pdfText(line,
                    style: pw.TextStyle(
                        fontStyle: pw.FontStyle.italic, fontSize: style.bodyFontSize)),
            ],
          ),
          pw.Column(
            crossAxisAlignment: pw.CrossAxisAlignment.end,
            children: [
              pdfText("FACTURÉ À",
                  style: pw.TextStyle(
                      fontWeight: pw.FontWeight.bold,
                      fontSize: style.labelFontSize,
                      color: accentColor)),
              pw.SizedBox(height: style.headerGap),
              pdfText(invoice.customer.name,
                  style: pw.TextStyle(
                      fontWeight: pw.FontWeight.bold, fontSize: style.bodyFontSize)),
              if (showCustomerBusinessName && invoice.customer.businessName.isNotEmpty)
                pdfText(invoice.customer.businessName,
                    style: pw.TextStyle(fontSize: style.bodyFontSize)),
              if (showCustomerAddress && invoice.customer.address.isNotEmpty)
                pdfText(invoice.customer.address,
                    style: pw.TextStyle(fontSize: style.bodyFontSize)),
              if (showCustomerPhone && invoice.customer.phone.isNotEmpty)
                pdfText(invoice.customer.phone,
                    style: pw.TextStyle(fontSize: style.bodyFontSize)),
              if (showCustomerEmail && invoice.customer.email.isNotEmpty)
                pdfText(invoice.customer.email,
                    style: pw.TextStyle(fontSize: style.bodyFontSize)),
              if (showGst && showCustomerGstin && invoice.customer.gstin.isNotEmpty)
                pdfText(
                    "${taxLabel(company?.country)}: ${invoice.customer.gstin}",
                    style: pw.TextStyle(
                        fontStyle: pw.FontStyle.italic, fontSize: style.bodyFontSize)),
            ],
          ),
        ],
      ),

      if (invoice.customFields.any((f) => f.value.trim().isNotEmpty)) ...[
        pw.SizedBox(height: 8),
        () {
          final filled = invoice.customFields
              .where((f) => f.value.trim().isNotEmpty)
              .toList();
          pw.Widget fieldCell(CustomFieldValue? f) => pw.Padding(
                padding: const pw.EdgeInsets.only(right: 8, bottom: 6),
                child: f == null
                    ? null
                    : pw.Column(
                        crossAxisAlignment: pw.CrossAxisAlignment.start,
                        children: [
                          pdfText(f.label,
                              style: pw.TextStyle(
                                  fontSize: style.bodyFontSize,
                                  fontWeight: pw.FontWeight.bold)),
                          pdfText(f.value,
                              style: pw.TextStyle(fontSize: style.bodyFontSize)),
                        ],
                      ),
              );
          return pw.Table(
            columnWidths: const {
              0: pw.FlexColumnWidth(1),
              1: pw.FlexColumnWidth(1),
              2: pw.FlexColumnWidth(1),
            },
            children: [
              for (var i = 0; i < filled.length; i += 3)
                pw.TableRow(children: [
                  fieldCell(filled[i]),
                  fieldCell(i + 1 < filled.length ? filled[i + 1] : null),
                  fieldCell(i + 2 < filled.length ? filled[i + 2] : null),
                ]),
            ],
          );
        }(),
      ],

      pw.SizedBox(height: 5),

      buildInvoiceTable(invoice,
          InvoiceTemplate.minimal,
          pageFormat,
          headerColor: PdfColors.grey100,
          textColor: PdfColors.black,
          showGst: showGst,
          showSlNo: showSlNo,
          showQuantity: showQuantity,
          showDiscount: showDiscount,
          showTypeTag: showTypeTag,
          showAliasName: showAliasName,
          showDescription: showDescription,
          descriptionNewLine: descriptionNewLine,
          businessType: businessType,
          watermarkBytes: fullPageWatermark ? null : watermarkBytes,
          watermarkOpacity: watermarkOpacity,
          tableFontSize: minimalPdfStyle.tableFontSize * tableItemsScale,
          tableHeaderFontSize: minimalPdfStyle.tableFontSize * tableHeaderScale,
          columnScale: tableItemsScale > tableHeaderScale ? tableItemsScale : tableHeaderScale,
          showCgstSgst: showCgstSgst, showIgst: showIgst,
          showTaxColumn: showTaxColumn,
          metadataColumns: metadataColumns,
          metadataDatePattern: datePattern),

      pw.SizedBox(height: 5),

      pw.Row(
        crossAxisAlignment: pw.CrossAxisAlignment.start,
        mainAxisAlignment: pw.MainAxisAlignment.spaceBetween,
        children: [
          pw.Expanded(child: buildAdditionalNotes(invoice, fontSize: 10 * fontSizeScale, accentColor: accentColor)),
          pw.SizedBox(width: 20),
          buildEnhancedTotals(
            invoice,
            PdfColors.grey200,
            PdfColors.black,
            accentColor,
            currencySymbol,
            previousBalanceDue: previousBalanceDue,
            fontSize: minimalPdfStyle.totalsFontSize * totalsScale,
            showCgstSgst: showCgstSgst, showIgst: showIgst,
            showRoundOff: showRoundOff,
          ),
        ],
      ),

      if (signatureImage != null || (showUpiQr && upiId != null) || bankAccount != null) ...[
        pw.SizedBox(height: 5),
        pw.Row(
          crossAxisAlignment: pw.CrossAxisAlignment.start,
          mainAxisAlignment: pw.MainAxisAlignment.spaceBetween,
          children: signaturePosition == 'right'
              ? [
                  buildBankUpiRow(
                    bankAccount: bankAccount,
                    showUpiQr: showUpiQr,
                    upiId: upiId,
                    companyName: company?.name ?? '',
                    amount: invoice.outstandingBalance,
                    currencyCode: invoice.currencyCode,
                    invoiceId: invoice.id,
                    accentColor: accentColor,
                    bankFontSize: 7.5 * fontSizeScale,
                    sectionTitleFontSize: 8 * fontSizeScale,
                    upiIdFontSize: 7 * fontSizeScale,
                    upiAmountFontSize: 7 * fontSizeScale,
                  ),
                  signatureImage != null
                      ? buildSignatureWidget(signatureImage, signaturePosition,
                          imageHeight: signatureSizePx,
                          labelFontSize: 9 * fontSizeScale)
                      : pw.SizedBox(),
                ]
              : [
                  signatureImage != null
                      ? buildSignatureWidget(signatureImage, signaturePosition,
                          imageHeight: signatureSizePx,
                          labelFontSize: 9 * fontSizeScale)
                      : pw.SizedBox(),
                  buildBankUpiRow(
                    bankAccount: bankAccount,
                    showUpiQr: showUpiQr,
                    upiId: upiId,
                    companyName: company?.name ?? '',
                    amount: invoice.outstandingBalance,
                    currencyCode: invoice.currencyCode,
                    invoiceId: invoice.id,
                    accentColor: accentColor,
                    bankFontSize: 7.5 * fontSizeScale,
                    sectionTitleFontSize: 8 * fontSizeScale,
                    upiIdFontSize: 7 * fontSizeScale,
                    upiAmountFontSize: 7 * fontSizeScale,
                  ),
                ],
        ),
      ],

      pw.SizedBox(height: 20),

      pw.Center(
        child: pdfText(thankyouNote,
            style: pw.TextStyle(
                color: accentColor,
                fontSize: PdfLayout.thankYouNoteFontSize * fontSizeScale,
                fontWeight: pw.FontWeight.bold)),
      ),
    ],
  );
}
