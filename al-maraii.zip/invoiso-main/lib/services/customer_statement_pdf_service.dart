import 'dart:typed_data';
import 'package:intl/intl.dart';
import 'package:invoiso/common/common.dart';
import 'package:invoiso/common/constants.dart';
import 'package:invoiso/models/report_models.dart';
import 'package:invoiso/services/backend_services.dart';
import 'package:invoiso/services/pdf/pdf_font_service.dart';
import 'package:invoiso/services/pdf/pdf_report_header.dart';
import 'package:pdf/pdf.dart';
import 'package:pdf/widgets.dart' as pw;
import 'package:invoiso/services/pdf/pdf_text.dart';

class CustomerStatementPdfService {
  static Future<Uint8List> export(
    List<CustomerStatement> statements, {
    bool showFooterBranding = true,
  }) async {
    final theme = await PdfFontService.loadTheme();
    final doc = pw.Document(theme: theme);
    final company = await BackendServices.companyInfo.getCompanyInfo();
    final dateFmt = (await BackendServices.settings.getDateFormat()).key;
    final generatedOn = DateFormat(dateFmt, 'en_US').format(DateTime.now());

    String formatStatementDate(String value) {
      final parsed = DateTime.tryParse(value);
      return parsed == null ? value : DateFormat(dateFmt, 'en_US').format(parsed);
    }

    for (final statement in statements) {
      String money(num v) => '${statement.currencySymbol} ${v.toStringAsFixed(2)}';

      doc.addPage(
        pw.MultiPage(
          pageFormat: PdfPageFormat.a4,
          margin: const pw.EdgeInsets.all(32),
          header: (context) => pw.Column(
            crossAxisAlignment: pw.CrossAxisAlignment.start,
            children: [
              PdfReportHeader.build(
                  company: company, title: 'RELEVÉ CLIENT', generatedOn: generatedOn),
              // ── Statement subject + currency/opening balance ───────────
              pw.Row(
                mainAxisAlignment: pw.MainAxisAlignment.spaceBetween,
                crossAxisAlignment: pw.CrossAxisAlignment.start,
                children: [
                  pw.Column(
                    crossAxisAlignment: pw.CrossAxisAlignment.start,
                    children: [
                      pdfText('RELEVÉ POUR',
                          style: pw.TextStyle(
                              fontSize: 8,
                              fontWeight: pw.FontWeight.bold,
                              color: PdfColors.grey600,
                              letterSpacing: 1)),
                      pw.SizedBox(height: 2),
                      pdfText(statement.customerName,
                          style: pw.TextStyle(fontSize: 10, fontWeight: pw.FontWeight.bold)),
                    ],
                  ),
                  pw.Column(
                    crossAxisAlignment: pw.CrossAxisAlignment.end,
                    children: [
                      pdfText('Currency: ${statement.currencyCode}',
                          style: const pw.TextStyle(fontSize: 9)),
                      pw.SizedBox(height: 2),
                      pdfText('Opening Balance: ${money(statement.openingBalance)}',
                          style: const pw.TextStyle(fontSize: 9)),
                    ],
                  ),
                ],
              ),
              pw.SizedBox(height: 12),
            ],
          ),
          footer: (context) => pw.Container(
            alignment: pw.Alignment.centerRight,
            margin: const pw.EdgeInsets.only(top: 16),
            child: pdfText(
              showFooterBranding
                  ? "Page ${context.pageNumber} sur ${context.pagesCount}  -  Généré par Al Maraii"
                  : "Page ${context.pageNumber} sur ${context.pagesCount}",
              style: pw.TextStyle(fontSize: PdfLayout.footerBrandingFontSize, color: PdfColors.grey600),
            ),
          ),
          build: (context) => [
            pw.TableHelper.fromTextArray(
              headers: ['N°', 'Date', 'Type', 'Référence', 'Désignation', 'Débit', 'Crédit', 'Solde'],
              data: List<List<String>>.generate(statement.lines.length, (i) {
                final line = statement.lines[i];
                return [
                  '${i + 1}',
                  formatStatementDate(line.date),
                  line.type,
                  line.reference,
                  line.description,
                  line.debit == 0 ? '' : money(line.debit),
                  line.credit == 0 ? '' : money(line.credit),
                  money(line.balance),
                ];
              }),
              headerStyle: pw.TextStyle(fontWeight: pw.FontWeight.bold, fontSize: 9, color: PdfColors.white),
              cellStyle: const pw.TextStyle(fontSize: 8),
              headerDecoration: const pw.BoxDecoration(color: PdfReportHeader.accentColor),
              cellAlignments: {
                0: pw.Alignment.centerRight,
                1: pw.Alignment.centerLeft,
                2: pw.Alignment.centerLeft,
                3: pw.Alignment.centerLeft,
                4: pw.Alignment.centerLeft,
                5: pw.Alignment.centerRight,
                6: pw.Alignment.centerRight,
                7: pw.Alignment.centerRight,
              },
              cellHeight: 20,
              oddRowDecoration: const pw.BoxDecoration(color: PdfColor.fromInt(0xFFF8FAFC)),
            ),
            pw.SizedBox(height: 12),
            pw.Container(
              padding: const pw.EdgeInsets.all(10),
              decoration: pw.BoxDecoration(
                color: PdfColors.grey100,
                borderRadius: pw.BorderRadius.circular(4),
              ),
              child: pw.Row(
                mainAxisAlignment: pw.MainAxisAlignment.end,
                children: [
                  pdfText(
                    'Invoiced: ${money(statement.invoiced)}   Paid: ${money(statement.paid)}   '
                    'Closing Balance: ${money(statement.closingBalance)}   Overdue: ${money(statement.overdueBalance)}',
                    style: pw.TextStyle(fontSize: 10, fontWeight: pw.FontWeight.bold),
                  ),
                ],
              ),
            ),
          ],
        ),
      );
    }
    return doc.save();
  }
}
